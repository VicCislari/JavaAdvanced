<?php
declare(strict_types=1);

namespace robske_110\collabcanvas;

use Amp\Loop;
use robske_110\collabcanvas\api\HttpServer;
use robske_110\collabcanvas\canvas\CanvasChangeTracker;
use robske_110\collabcanvas\canvas\CanvasStore;
use robske_110\collabcanvas\canvas\DisplayNameStore;
use robske_110\collabcanvas\db\DatabaseConnection;
use robske_110\collabcanvas\room\RoomStore;
use robske_110\Logger\Logger;
use RuntimeException;

/**
 * @author Hartmann
 */
class CollabCanvasServer{
	private DatabaseConnection $databaseConnection;

	private RoomStore $roomStore;
	private CanvasChangeTracker $canvasChangeTracker;

	private HttpServer $httpServer;

	public function __construct(){
		Logger::log("Connecting to db...");
		$this->databaseConnection = new DatabaseConnection(
			$_ENV['CC_DB_HOST'],
			$_ENV['CC_DB_NAME'],
			$_ENV['CC_DB_USER'],
			$_ENV['CC_DB_PASSWORD'] ?? null
		);
		if(!is_string($_ENV['MASTER_CODE']) || strlen($_ENV['MASTER_CODE']) <= 6){
			throw new RuntimeException("MASTER_CODE must be set and longer than 6 characters!");
		}
		if(!is_string($_ENV['MASTER_NAME']) || empty($_ENV['MASTER_NAME'])){
			throw new RuntimeException("MASTER_NAME must be set and not empty!");
		}
		$this->databaseConnection->getConnection()->exec(
			file_get_contents(__DIR__.DIRECTORY_SEPARATOR."db".DIRECTORY_SEPARATOR."tables.sql")
		);

		$this->roomStore = new RoomStore(
			$this->databaseConnection, new CanvasStore(
				$this->databaseConnection, new DisplayNameStore($this->databaseConnection)
			)
		);

		$this->canvasChangeTracker = new CanvasChangeTracker();

		$this->httpServer = new HttpServer((int) $_ENV['CC_PORT'] ?? 80, $this->roomStore, $this->canvasChangeTracker);
	}

	public function start(){
		$this->httpServer->start();
		Loop::run(function(){
			if(extension_loaded("pcntl")){
				Loop::onSignal(SIGINT, $this->shutdown(...));
			}
		});
	}

	public function shutdown(){
		$this->httpServer->stop();
		Loop::stop();
	}
}