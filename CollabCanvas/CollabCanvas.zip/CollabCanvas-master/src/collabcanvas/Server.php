<?php
declare(strict_types=1);

namespace robske_110\collabcanvas;

/** @author Hartmann */

ini_set("memory_limit", "8G");

const BASE_DIR = __DIR__.DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR;

/* Load Composer Autoloader. */
require BASE_DIR."vendor/autoload.php";

// Load environment variables
$_ENV = getenv(); //Manually populate the $_ENV superglobal for configurations which disabled it.
/**
 * Loading environment variables from file.
 * We do not load environment variables from file when --ignore-env-file is passed.
 * This is done to allow prioritising the real environment over the file, and is used by the docker configuration.
*/
const ENV_FILE = BASE_DIR.".env";
if(!str_contains($_SERVER['argv'][1] ?? "", "--ignore-env-file") && file_exists(ENV_FILE)){
	foreach(parse_ini_file(ENV_FILE, false, INI_SCANNER_TYPED) as $key => $var){
		$_ENV[$key] = $var;
	}
}

use robske_110\Logger\Logger;

Logger::init();

$collabCanvasServer = new CollabCanvasServer();
$collabCanvasServer->start();