<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api;

use Amp\Http\Cookie\CookieAttributes;
use Amp\Http\Server\HttpServer as AmpHttpServer;
use Amp\Http\Server\Middleware;
use Amp\Http\Server\Options;
use Amp\Http\Server\RequestHandler\CallableRequestHandler;
use Amp\Http\Server\Response;
use Amp\Http\Server\Router;
use Amp\Http\Server\Session\Driver;
use Amp\Http\Server\Session\InMemoryStorage;
use Amp\Http\Server\Session\SessionMiddleware;
use Amp\Http\Server\StaticContent\DocumentRoot;
use Amp\Http\Status;
use Amp\Socket\Server;
use Amp\Sync\LocalKeyedMutex;
use robske_110\collabcanvas\api\endpoints\AuthDestroy;
use robske_110\collabcanvas\api\endpoints\AuthRoom;
use robske_110\collabcanvas\api\endpoints\AuthSystem;
use robske_110\collabcanvas\api\endpoints\CanvasImageData;
use robske_110\collabcanvas\api\endpoints\CanvasImageUpdates;
use robske_110\collabcanvas\api\endpoints\CanvasSetPixel;
use robske_110\collabcanvas\api\endpoints\DisplayNameRepository;
use robske_110\collabcanvas\api\endpoints\RoomAuthenticationInfo;
use robske_110\collabcanvas\api\endpoints\RoomCreate;
use robske_110\collabcanvas\api\endpoints\RoomData;
use robske_110\collabcanvas\api\endpoints\RoomDelete;
use robske_110\collabcanvas\api\endpoints\RoomPatch;
use robske_110\collabcanvas\api\endpoints\RoomRepository;
use robske_110\collabcanvas\canvas\CanvasChangeTracker;
use robske_110\collabcanvas\room\RoomStore;
use robske_110\Logger\PSRLogger;
use function Amp\call;
use const robske_110\collabcanvas\BASE_DIR;

/**
 * @author Hartmann, Ermis
 *
 * The HttpServer configures and hosts the AmpHttpServer, which provides the api and web application data to clients.
 */
class HttpServer{
	private AmpHttpServer $server;

	/**
	 * @param int $port
	 * @param RoomStore $roomStore handles db connection and room caching
	 * @param CanvasChangeTracker $canvasChangeTracker
	 */
	public function __construct(
		int $port, private RoomStore $roomStore, private CanvasChangeTracker $canvasChangeTracker
	){
		$sockets = [
			Server::listen("0.0.0.0:".$port), //IPv4
			Server::listen("[::]:".$port) //IPv6
		];
		$this->server = new AmpHttpServer(
			$sockets,
			Middleware\stack(
				$this->buildRouter(),
				new SessionMiddleware(
					new Driver(new LocalKeyedMutex, new InMemoryStorage),
					CookieAttributes::default()->withPath("/")
				)
			),
			new PSRLogger,
			(new Options())->withConnectionsPerIpLimit(10000)
		);
	}

	/**
	 * Start the HTTP Server.
	 */
	public function start(){
		call(function(){
			yield $this->server->start();
		});
	}

	/**
	 * Stops the HTTP Server, allowing client connections to gracefully shutdown.
	 */
	public function stop(){
		call(function(){
			yield $this->server->stop();
		});
	}

	/**
	 * @return Router
	 */
	private function buildRouter(): Router{
		$router = new Router;
		$router->addRoute("GET", "/cc", new CallableRequestHandler(function(){
			return new Response(
				Status::OK, ["content-type" => "text/plain; charset=utf-8"],
				"CollabCanvas 👍"
			);
		}));

		$router->addRoute("PUT", "/api/room", new RoomCreate($this->roomStore));
		$router->addRoute("GET", "/api/room/{roomID:\d+}", new RoomData($this->roomStore));
		$router->addRoute("PATCH", "/api/room/{roomID:\d+}", new RoomPatch($this->roomStore));
		$router->addRoute("DELETE", "/api/room/{roomID:\d+}", new RoomDelete($this->roomStore));
		$router->addRoute("GET", "/api/room", new RoomRepository($this->roomStore));
		$router->addRoute("GET", "/api/room/{roomID:\d+}/authinfo",
			new RoomAuthenticationInfo($this->roomStore)
		);
		$router->addRoute("GET", "/api/room/{roomID:\d+}/canvas/imagedata",
			new CanvasImageData($this->roomStore, $this->canvasChangeTracker)
		);
		$router->addRoute("GET", "/api/room/{roomID:\d+}/canvas/imageupdates",
			new CanvasImageUpdates($this->roomStore, $this->canvasChangeTracker)
		);
		$router->addRoute("GET", "/api/room/{roomID:\d+}/canvas/displaynames",
			new DisplayNameRepository($this->roomStore)
		);
		$router->addRoute(
			"GET", "/api/room/{roomID:\d+}/canvas/displayname/{displayNameID:\d+}",
			new DisplayNameRepository($this->roomStore)
		);
		$router->addRoute("PUT", "/api/room/{roomID:\d+}/canvas/pixel",
			new CanvasSetPixel($this->roomStore, $this->canvasChangeTracker)
		);
		$router->addRoute("POST", "/api/room/{roomID:\d+}/auth", new AuthRoom($this->roomStore));
		$router->addRoute("POST", "/api/system/auth", new AuthSystem());
		$router->addRoute("POST", "/api/logout", new AuthDestroy()); //full logout, also for RoomAuth


		//Serve static files from the DocumentRoot if no other routes match
		$router->setFallback(new DocumentRoot(BASE_DIR."public"));
		return $router;
	}
}