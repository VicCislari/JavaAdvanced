<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\response;

use Amp\Http\Server\Response;
use Amp\Http\Status;

/** @author Hartmann */
abstract class JSONResponse{
	public static function create(mixed $content, int $statusCode = Status::OK): Response{
		return new Response(
			$statusCode,
			["content-type" => "application/json; charset=utf-8", "Cache-Control" => "no-cache"],
			json_encode($content, JSON_THROW_ON_ERROR)
		);
	}
}