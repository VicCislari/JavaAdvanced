<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\canvas\CanvasChangeTracker;
use robske_110\collabcanvas\canvas\Pixel;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\RoomStore;
use function Amp\call;

/**
 * Sets pixel on a canvas, with the appropriate permission checks.
 * @author Ermis, Hartmann
 */
class CanvasSetPixel extends RoomEndpoint implements RequestHandler{
	public function __construct(RoomStore $roomStore, private CanvasChangeTracker $canvasChangeTracker){
		parent::__construct($roomStore);
	}

	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$room = $this->getRoomFromRequest($request);
				$canvas = $room->getCanvas();
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			//get coordinates at which pixel is intended to be set
			$body = json_decode(yield $request->getBody()->buffer());

			if(!is_int($body->x) || !is_int($body->y)){
				return JSONResponse::create("Invalid/missing coordinates!", Status::BAD_REQUEST);
			}
			if(!is_int($body->r) || !is_int($body->g) || !is_int($body->b)){
				return JSONResponse::create("Invalid/missing color!", Status::BAD_REQUEST);
			}

			$x = $body->x;
			$y = $body->y;

			//retrieve code used by user
			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			$sessionCode = $session->get("code");
			$isMaster = $session->get("isMaster") ?? false;

			if($sessionCode === null && !$isMaster){
				return JSONResponse::create("Not authorized", Status::UNAUTHORIZED);
			}

			// initialise displayNameId in current room when user is master
			if($isMaster){
				$session->set(
					'displayNameId',
					$this->roomStore->getCanvasStore()->getDisplaynameStore()->createOrGetLocalIdForDisplayName(
						$this->roomStore->getCanvasStore()->getCanvasId($canvas),
						$_ENV["MASTER_NAME"] //master always has the same name
					)
				);
			}

			//check if code is valid for the current room and if the pixel coordinates are within the section for the given code
			/*if(!$isMaster && ($division = $room->hasDivisionAccess($sessionCode)) !== null){
				Logger::var_dump($division);
				Logger::var_dump($division->contains($x, $y), "division->contains(".$x.",".$y.")");
			}*/
			if(
				!$isMaster && !$room->hasFullAccess($sessionCode) &&
				(($division = $room->hasDivisionAccess($sessionCode)) !== null && !$division->contains($x, $y))
			){
				return JSONResponse::create("Insufficient authorisation", Status::FORBIDDEN);
			}
			//set Pixel
			$this->canvasChangeTracker->setPixel($canvas, new Pixel($x, $y, $body->r, $body->g, $body->b, $session->get("displayNameId")));

			$this->roomStore->getCanvasStore()->deferredSave($canvas);

			return JSONResponse::create("pixel is set");
		});
	}
}