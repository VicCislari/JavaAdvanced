<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use function Amp\call;

/**
 * Returns simple properties of a Room and its Canvas
 * @author Hartmann, Ermis
 */
class RoomData extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$room = $this->getRoomFromRequest($request);
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}
			$divisions = [];
			foreach($room->getDivisions() as $division){
				$divisions[] = [
					"start" => ["x" => $division->xStart, "y" => $division->yStart],
					"end" => ["x" => $division->xEnd, "y" => $division->yEnd]
				];
			}
			return JSONResponse::create([
				"roomName" => $room->getRoomName(),
				"official" => $room->isOfficial(),
				"divisions" => $divisions,
				"pixelSetDelay" => $room->getPixelSetDelay(),
				"canvas" => [
					"width" => $room->getCanvas()->getWidth(),
					"height" => $room->getCanvas()->getHeight()
				]
			]);
		});
	}
}