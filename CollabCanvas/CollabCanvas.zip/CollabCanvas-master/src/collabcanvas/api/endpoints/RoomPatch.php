<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use function Amp\call;

/** 
 * Allows to change the official status of a room if the user is authenticated as MASTER.
 * @author Hartmann, Ermis, Brieger
 */
class RoomPatch extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$room = $this->getRoomFromRequest($request);
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			if(!$session->get("isMaster") ?? false){
				return JSONResponse::create("Not allowed!", Status::FORBIDDEN);
			}

			$request = json_decode(yield $request->getBody()->buffer(), true, JSON_THROW_ON_ERROR);

			if(!is_bool($request["official"] ?? null)){
				return JSONResponse::create("Invalid official value!", Status::BAD_REQUEST);
			}

			$room->setOfficial($request["official"]);
			$this->roomStore->saveRoom($room);
			
			return JSONResponse::create("success");
		});
	}
}