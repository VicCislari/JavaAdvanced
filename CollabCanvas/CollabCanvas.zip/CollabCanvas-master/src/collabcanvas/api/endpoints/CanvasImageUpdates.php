<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Router;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\canvas\CanvasChangeTracker;
use robske_110\collabcanvas\canvas\exception\ChangeUnknown;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\RoomStore;
use function Amp\call;

/**
 * Returns a list of changes made to the canvas after a given update ID, returning the new updateId
 * @author Hartmann
 */
class CanvasImageUpdates extends RoomEndpoint implements RequestHandler{
	public function __construct(RoomStore $roomStore, private CanvasChangeTracker $canvasChangeTracker){
		parent::__construct($roomStore);
	}

	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$canvas = $this->getRoomFromRequest($request)->getCanvas();
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			//get and validate the updateId parameter from the query string
			parse_str($request->getUri()->getQuery(), $queryParams);
			if(!isset($queryParams['after']) || !is_numeric($queryParams['after'])){
				return JSONResponse::create("Must specify ?after=<updateID>!", Status::BAD_REQUEST);
			}
			$updateId = (int) $queryParams['after'];

			try{
				return JSONResponse::create([
					"updateId" => (string) $this->canvasChangeTracker->getUpdateId($canvas),
					//js can't easily handle 64bit, which is why we need to send the updateId as a string
					"updates" => $this->canvasChangeTracker->getChangesAfter($canvas, $updateId)
				]);
			}catch(ChangeUnknown){
				return JSONResponse::create(
					"updateId is unknown, full reload required!",
					Status::NOT_FOUND
				);
			}
		});
	}
}