<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use function Amp\call;

/**
 * Checks if user is eligible to make changes to room, or (on TeamCanvas) which division of the room
 * @author Hartmann, Ermis
 */
class RoomAuthenticationInfo extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$room = $this->getRoomFromRequest($request);
				$canvas = $room->getCanvas();
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			$sessionCode = $session->get("code");
			$isMaster = $session->get("isMaster") ?? false;

			if($sessionCode === null && !$isMaster){
				return JSONResponse::create("Not authorized", Status::UNAUTHORIZED);
			}

			if(!$isMaster && !$room->hasAnyAccess($sessionCode)){
				return JSONResponse::create("Not authorized for this room", Status::UNAUTHORIZED);
			}


			if(!$isMaster){
				$divisionId = array_search($room->hasDivisionAccess($sessionCode), $room->getDivisions(), true);
				if($divisionId === false){ //no division
					$divisionId = null;
				}
			}else{
				$divisionId = null;
			}


			$canvasStore = $this->roomStore->getCanvasStore();
			return JSONResponse::create([
				"isAdmin" => $isMaster || $room->hasAdminAccess($sessionCode),
				"divisionId" => $divisionId,
				"displayName" =>
					$isMaster ?
					$_ENV["MASTER_NAME"] :
					$canvasStore->getDisplaynameStore()->getDisplayNameByLocal(
						$canvasStore->getCanvasId($canvas), $session->get("displayNameId")
					),
			]);
		});
	}
}