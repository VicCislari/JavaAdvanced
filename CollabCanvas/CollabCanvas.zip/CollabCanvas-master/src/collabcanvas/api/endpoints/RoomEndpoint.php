<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\Router;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\Room;
use robske_110\collabcanvas\room\RoomStore;

/**
 * Base class for all Room endpoints (having <roomId> in their URI).
 * Provides an easy way to get the specified Room object.
 *
 * @author Hartmann
 */
abstract class RoomEndpoint{
	public function __construct(protected readonly RoomStore $roomStore){
	}

	/**
	 * @param Request $request
	 * @return Room
	 * @throws RoomNotFoundException
	 */
	public function getRoomFromRequest(Request $request): Room{
		$roomId = (int) $request->getAttribute(Router::class)['roomID'] ?? null;
		return $this->roomStore->getRoom($roomId);
	}
}