<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use function Amp\call;

/**
 * This endpoint deletes a Room.
 * @author Hartmann, Ermis, Brieger
 */
class RoomDelete extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$room = $this->getRoomFromRequest($request);
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			$sessionCode = $session->get("code");
			$isMaster = $session->get("isMaster") ?? false;

			if($sessionCode === null && !$isMaster){
				return JSONResponse::create("Not authenticated", Status::UNAUTHORIZED);
			}

			if($isMaster || $room->hasAdminAccess($sessionCode)){
				$this->roomStore->deleteRoom($room);
				return JSONResponse::create("Room deleted");
			}else{
				return JSONResponse::create("Not authorized", Status::FORBIDDEN);
			}
		});
	}
}