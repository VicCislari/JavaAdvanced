<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Response;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\canvas\CanvasChangeTracker;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\RoomStore;
use function Amp\call;

/**
 * Returns the packed Canvas image Data (see {@link \robske_110\collabcanvas\canvas\Canvas}).
 * At the end a 64 bit update identifier is appended.
 * @author Hartmann
 */
class CanvasImageData extends RoomEndpoint implements RequestHandler{
	public function __construct(RoomStore $roomStore, private CanvasChangeTracker $canvasChangeTracker){
		parent::__construct($roomStore);
	}

	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$canvas = $this->getRoomFromRequest($request)->getCanvas();
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}
			return new Response(
				Status::OK,
				["content-type" => "application/octet-stream"],
				$canvas->getImageData().pack("P", $this->canvasChangeTracker->getUpdateId($canvas))
			);
		}); //updateId is appended as int64 little endian
	}
}