<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\auth\Code;
use robske_110\collabcanvas\canvas\Canvas;
use robske_110\collabcanvas\room\exception\RoomNotManagedException;
use robske_110\collabcanvas\room\Room;
use robske_110\Logger\Logger;
use function Amp\call;

/** @author Hartmann, Ermis */
class RoomCreate extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			$request = json_decode(yield $request->getBody()->buffer(), true, JSON_THROW_ON_ERROR);

			if(!is_int($request["divisionCount"] ?? null) || $request["divisionCount"] < 0){
				return JSONResponse::create("Invalid divisionCount!", Status::BAD_REQUEST);
			}

			if(
				!is_int($request["width"] ?? null) || !is_int($request["height"]) ||
				$request["width"] < 1 || $request["height"] < 1
			){
				return JSONResponse::create("Invalid divisionCount!", Status::BAD_REQUEST);
			}

			if(
				!is_int($request["pixelSetDelay"] ?? null) || $request["pixelSetDelay"] < 0
			){
				return JSONResponse::create("Invalid pixelSetDelay!", Status::BAD_REQUEST);
			}

			$adminCode = new Code(true);
			$roomCode = new Code(false);

			if($request["divisionCount"] == 1){
				$canvas = new Canvas($request["width"], $request["height"]);
			}else{
				$canvasSize = Room::calculateCanvasSize($request["divisionCount"], $request["width"], $request["height"]);
				$canvas = new Canvas(...$canvasSize);
			}

			$room = new Room(
				$request["name"],
				false,
				$canvas,
				$request["pixelSetDelay"],
				[],
				[$adminCode, $roomCode]
			);

			if($request["divisionCount"] > 1){
				$room->createDivisions($request["divisionCount"]);
			}

			try{
				$roomId = $this->roomStore->saveRoom($room);
			}catch(RoomNotManagedException){
				return JSONResponse::create("roomName is already used!", Status::CONFLICT);
			}

			Logger::var_dump($room, "room");

			$divisionCodes = [];
			foreach($room->getDivisions() as $division){
				$divisionCodes[] = $division->code->code;
			}

			return JSONResponse::create([
				"adminCode" => $adminCode->code,
				"roomCode" => $roomCode->code,
				"roomId" => $roomId,
				"divisionCodes" => $divisionCodes
			]);
		});
	}
}