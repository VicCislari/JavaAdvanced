<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use RuntimeException;
use function Amp\call;

/**
 * Authenticates a user on a system level. Used for authenticating as MASTER
 * @author Ermis, Hartmann
 */
class AuthSystem implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			$body = json_decode(yield $request->getBody()->buffer());
			if(!isset($body->code) || !is_string($body->code)){
				return JSONResponse::create("No code given", Status::BAD_REQUEST);
			}

			$isMaster = hash_equals(
				$_ENV["MASTER_CODE"] ?? throw new RuntimeException("No master code is set!"),
				$body->code
			); //timing-attack safe string comparison

			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			$session->set('isMaster', $isMaster);
			yield $session->save();

			if($isMaster){
				return JSONResponse::create([
					"isAdmin" => true,
					"displayName" => $_ENV["MASTER_NAME"]
				]);
			}else{
				return JSONResponse::create("User is not verified!", Status::UNAUTHORIZED);
			}
		});
	}
}