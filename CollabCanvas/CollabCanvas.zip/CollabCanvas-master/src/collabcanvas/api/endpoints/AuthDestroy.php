<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use function Amp\call;

/** @author Hartmann */
class AuthDestroy implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			/** @var Session $session */
			$session = yield $request->getAttribute(Session::class)->open();
			$session->destroy();

			return JSONResponse::create("Successfully destroyed session!");
		});
	}
}