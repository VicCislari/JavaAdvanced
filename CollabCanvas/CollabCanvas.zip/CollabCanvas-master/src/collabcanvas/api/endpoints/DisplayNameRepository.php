<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Router;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\canvas\exception\DisplayNameNotFoundException;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use function Amp\call;

/**
 * Returns display-name corresponding to current user
 * if no ID given return all display-names for given canvas
 * @author Hartmann
 */
class DisplayNameRepository extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			try{
				$canvas = $this->getRoomFromRequest($request)->getCanvas();
			}catch(RoomNotFoundException){
				return JSONResponse::create("Could not find room!", Status::NOT_FOUND);
			}

			$canvasId = $this->roomStore->getCanvasStore()->getCanvasId($canvas);
			$displayNameStore = $this->roomStore->getCanvasStore()->getDisplaynameStore();

			if(($displayNameId = $request->getAttribute(Router::class)['displayNameID'] ?? null) !== null){
				$displayNameId = (int) $displayNameId;
				try{
					return JSONResponse::create($displayNameStore->getDisplayNameByLocal(
						$canvasId, $displayNameId)
					); //return one displayName
				}catch(DisplayNameNotFoundException){
					return JSONResponse::create(
						"Could not find specified displayName!", Status::NOT_FOUND
					);
				}
			}else{
				$gIds = $displayNameStore->getLocalDisplayNames($canvasId);
				$dNames = [];
				foreach($gIds as $gId){
					$dNames[] = $displayNameStore->getDisplayNameByGlobal($gId);
				}
				return JSONResponse::create($dNames); //return all displayNames
			}
		});
	}
}