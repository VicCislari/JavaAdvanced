<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\RoomStore;
use function Amp\call;

/**
 * Allows to find a room by Name (query parameter findByName) or
 * list the official Rooms (query parameter isOfficial=true)
 * @author Hartmann
 */
class RoomRepository implements RequestHandler{
	public function __construct(private RoomStore $roomStore){
	}

	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			parse_str($request->getUri()->getQuery(), $queryParams);
			if(isset($queryParams['findByName'])){
				try{
					$roomId = $this->roomStore->getRoomId($this->roomStore->findRoom($queryParams['findByName']));
				}catch(RoomNotFoundException){
					return JSONResponse::create("No room with that name found.", Status::NOT_FOUND);
				}
				return JSONResponse::create(["id" => $roomId]);
			}elseif(isset($queryParams['isOfficial'])){
				if($queryParams['isOfficial'] === "true"){
					return JSONResponse::create($this->roomStore->listOfficialRooms());
				}
			}
			return JSONResponse::create("Invalid", Status::BAD_REQUEST);
		});
	}
}