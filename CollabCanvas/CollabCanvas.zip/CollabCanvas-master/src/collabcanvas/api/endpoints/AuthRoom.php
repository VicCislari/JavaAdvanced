<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\api\endpoints;

use Amp\Http\Server\Request;
use Amp\Http\Server\RequestHandler;
use Amp\Http\Server\Session\Session;
use Amp\Http\Status;
use Amp\Promise;
use robske_110\collabcanvas\api\response\JSONResponse;
use function Amp\call;

/**
 * Authenticates a user on a room level.
 * Used to authenticate user in a room, giving them admin, full, or division access.
 * @author Ermis
 */
class AuthRoom extends RoomEndpoint implements RequestHandler{
	public function handleRequest(Request $request): Promise{
		return call(function() use ($request){
			$room = $this->getRoomFromRequest($request);
			$canvas = $room->getCanvas();
			$body = json_decode(yield $request->getBody()->buffer());

			if(strtolower($body->displayName) === strtolower($_ENV["MASTER_NAME"])){
				return JSONResponse::create("Administratorname kann nicht als Anzeigename verwendet werden!", Status::FORBIDDEN);
			}

			if($room->hasAnyAccess($body->code)){
				/** @var Session $session */
				$session = yield $request->getAttribute(Session::class)->open();
				$session->set('code', $body->code);
				$session->set(
					'displayNameId',
					$this->roomStore->getCanvasStore()->getDisplaynameStore()->createOrGetLocalIdForDisplayName(
						$this->roomStore->getCanvasStore()->getCanvasId($canvas), $body->displayName
					)
				);
				yield $session->save();

				$divisionId = array_search($room->hasDivisionAccess($body->code), $room->getDivisions(), true);
				if($divisionId === false){ //no division
					$divisionId = null;
				}

				return JSONResponse::create([
					"isAdmin" => $room->hasAdminAccess($body->code),
					"divisionId" => $divisionId
				]);
			}else{
				return JSONResponse::create("Code incorrect", Status::UNAUTHORIZED);
			}
		});
	}
}