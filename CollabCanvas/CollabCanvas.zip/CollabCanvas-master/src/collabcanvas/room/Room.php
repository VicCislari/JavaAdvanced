<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\room;

use InvalidArgumentException;
use robske_110\collabcanvas\auth\Code;
use robske_110\collabcanvas\canvas\Canvas;
use robske_110\Logger\Logger;
use RuntimeException;

/**
 * @author Ermis, Hartmann
 */
class Room{

	/**
	 * @param string $roomName
	 * @param bool $official
	 * @param Canvas $canvas
	 * @param int $pixelSetDelay
	 * @param RoomDivision[] $divisions
	 * @param Code[] $codes
	 */
	public function __construct(
		private string $roomName,
		private bool $official,
		private Canvas $canvas,
		private int $pixelSetDelay = 0,
		private array $divisions = [],
		private array $codes = []
	){
	}

	/**
	 * @return string
	 */
	public function getRoomName(): string{
		return $this->roomName;
	}

	/**
	 * @param string $roomName
	 */
	public function setRoomName(string $roomName): void{
		$this->roomName = $roomName;
	}

	/**
	 * @return bool
	 */
	public function isOfficial(): bool{
		return $this->official;
	}

	/**
	 * @param bool $official
	 */
	public function setOfficial(bool $official){
		$this->official = $official;
	}

	/**
	 * @return Canvas
	 */
	public function getCanvas(): Canvas{
		return $this->canvas;
	}

	public function getPixelSetDelay(): int{
		return $this->pixelSetDelay;
	}

	public function setPixelDelay(int $pixelDelay){
		$this->pixelSetDelay = $pixelDelay;
	}

	/**
	 * @return RoomDivision[]
	 */
	public function getDivisions(): array{
		return $this->divisions;
	}

	public function deleteDivisions(){
		$this->divisions = [];
	}

	/**
	 * Calculates a suitable division arrangement for the given divisionCount
	 * @param int $divisionCount
	 * @return int[] [xCount, yCount]
	 */
	public static function calculateDivisionArrangement(int $divisionCount): array{
		$sqrtDivCount = sqrt($divisionCount);
		$isSquare = floor($sqrtDivCount) == $sqrtDivCount;

		if($isSquare){
			// even number of divisions in both x and y directions (grid)
			return [(int) $sqrtDivCount, (int) $sqrtDivCount];
		}elseif(!self::isPrime($divisionCount)){
			// find divisionCounts in x and y direction, so that the difference between them is the smallest
			// example: for 12 divisions the arrangement should be 4 inx and 3 in y
			// This is archived by factorization
			$biggestDivider = 0;
			for($i = 1; $i < sqrt($divisionCount); $i++){
				$divider = $divisionCount / $i;
				if(floor($divider) == $divider){
					Logger::var_dump($divider, "divider");
					$biggestDivider = $divider;
				}
			}
			return [$biggestDivider, $divisionCount/$biggestDivider];
		}else{
			// if divisionCount is a prime number we can only make simple division stripes.
			return [$divisionCount, 1]; //Simple stripes in x direction
		}
	}

	/**
	 * Calculates size for creating new canvas with n divisions of a specific size
	 *
	 * @param int $divisionCount
	 * @param int $divisionSizeX
	 * @param int $divisionSizeY
	 * @return int[] [width (x), height (y)]
	 */
	public static function calculateCanvasSize(int $divisionCount, int $divisionSizeX, int $divisionSizeY): array{
		$arrangement = self::calculateDivisionArrangement($divisionCount);
		Logger::var_dump($arrangement, "arrangement");
		return [
			$arrangement[0] * $divisionSizeX,
			$arrangement[1] * $divisionSizeY
		];
	}

	/**
	 * Creates RoomDivision objects for this room
	 *
	 * @param int $divisionCount
	 *
	 * @throws RuntimeException
	 */
	public function createDivisions(int $divisionCount){
		if(!empty($this->divisions)){
			throw new RuntimeException("This room already has divisions, delete them before calling this!");
		}
		$arrangement = self::calculateDivisionArrangement($divisionCount);

		$divisionWidth = $this->canvas->getWidth() / $arrangement[0];
		$divisionHeight = $this->canvas->getHeight() / $arrangement[1];

		for($y = 0; $y < $arrangement[1]; $y++){
			for($x = 0; $x < $arrangement[0]; $x++){
				$this->divisions[] = new RoomDivision(
					$x * $divisionWidth,
					($x+1) * $divisionWidth - 1,
					$y * $divisionHeight,
					($y+1) * $divisionHeight - 1
				);
			}
		}
	}

	private static function isPrime(int $number): bool{
		if($number === 1) return false;

		for($i = 2; $i <= sqrt($number); $i++){
			if($number % $i == 0){
				return false;
			}
		}
		return true;
	}

	/**
	 * @return Code[]
	 */
	public function getCodes(): array{
		return $this->codes;
	}

	public function addCode(Code $code){
		$this->codes[] = $code;
	}

	public function deleteCodes(){
		$this->codes = [];
	}

	/**
	 * Checks if a user has any (write) access to this Room.
	 * Important: This also returns true when the user only has access to a division!
	 *
	 * @param string $codeFromUser
	 * @return bool Whether the user has any (write) access to this Room.
	 */
	public function hasAnyAccess(string $codeFromUser): bool{
		if($this->hasFullAccess($codeFromUser)){
			return true;
		}
		if($this->hasDivisionAccess($codeFromUser) !== null){
			return true;
		}
		return false;
	}

	/**
	 * Checks if a user has full (write) access to this Room.
	 *
	 * @param string $codeFromUser
	 * @return bool Whether the user has full (write) access to this Room.
	 */
	public function hasFullAccess(string $codeFromUser): bool{
		foreach($this->codes as $code){
			if($code->check($codeFromUser)){
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks if a user has (write) access to a specific Division and returns the RoomDivision the user has access to.
	 *
	 * @param string $codeFromUser
	 * @return RoomDivision|null The RoomDivision the user has access to, otherwise null
	 */
	public function hasDivisionAccess(string $codeFromUser): ?RoomDivision{
		foreach($this->divisions as $division){
			if($division->code->check($codeFromUser)){
				return $division;
			}
		}
		return null;
	}

	/**
	 * Checks if a user has admin access to this Room.
	 *
	 * @param string $codeFromUser
	 * @return bool Whether the User has admin access to this Room.
	 */
	public function hasAdminAccess(string $codeFromUser): bool{
		foreach($this->codes as $code){
			if($code->check($codeFromUser) && $code->isAdmin){
				return true;
			}
		}
		return false;
	}
}