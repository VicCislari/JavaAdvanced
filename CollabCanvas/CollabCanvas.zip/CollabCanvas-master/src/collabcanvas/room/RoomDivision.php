<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\room;

use robske_110\collabcanvas\auth\Code;
use RuntimeException;

/**
 * Represents a RoomDivision
 * @author Ermis, Hartmann
 */
class RoomDivision{

	public function __construct(
		public readonly int $xStart,
		public readonly int $xEnd,
		public readonly int $yStart,
		public readonly int $yEnd,
		public readonly Code $code = new Code(false)
	){
		if($this->xStart > $this->xEnd || $this->yStart > $this->yEnd){
			throw new RuntimeException("Division coordinates are incorrect!");
		}
	}

	public function contains(int $x, int $y): bool{
		return
			$this->xStart <= $x &&
			$this->yStart <= $y &&
			$x <= $this->xEnd &&
			$y <= $this->yEnd;
	}
}