<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\room;

use PDO;
use PDOException;
use PDOStatement;
use robske_110\collabcanvas\auth\Code;
use robske_110\collabcanvas\canvas\CanvasStore;
use robske_110\collabcanvas\db\DatabaseConnection;
use robske_110\collabcanvas\room\exception\RoomNotFoundException;
use robske_110\collabcanvas\room\exception\RoomNotManagedException;

/**
 * The RoomStore class manages Room objects. It provides mechanisms to get Room objects by their database id or name and
 * write/read Room objects to/from the database. It includes a Room object cache.
 *
 * @author Hartmann, Brieger
 */
class RoomStore{
	/** @var Room[] */
	public array $rooms = [];

	private PDOStatement $findRoom;

	public function __construct(private DatabaseConnection $dbConnection, private CanvasStore $canvasStore){
		$this->findRoom = $this->dbConnection->prepare("SELECT room_id FROM room WHERE name=?");
	}

	public function getCanvasStore(): CanvasStore{
		return $this->canvasStore;
	}

	/**
	 * @param Room $room
	 *
	 * @return int The database roomId of the given Room object
	 */
	public function getRoomId(Room $room){
		$roomId = array_search($room, $this->rooms, true);
		if($roomId === false){
			throw new RoomNotFoundException("Could not find the specified Room!");
		}
		return $roomId;
	}

	/**
	 * @param string $roomName The name of the room object to find
	 *
	 * @return Room
	 */
	public function findRoom(string $roomName): Room{
		$this->findRoom->execute([$roomName]);
		$roomId = $this->findRoom->fetch(PDO::FETCH_ASSOC)["room_id"] ?? null;
		if($roomId === null){
			throw new RoomNotFoundException("Could not find Room with name ".$roomName);
		}
		return $this->getRoom($roomId);
	}

	public function getRoom(int $roomId): Room{
		if(!isset($this->rooms[$roomId])){
			//load room
			$room =
				$this->dbConnection->query(
					"SELECT name, canvas_id, official, pixel_set_delay FROM room WHERE room_id=".$roomId
				)[0] ?? null;
			if($room === null){
				throw new RoomNotFoundException("Unable to find room with id ".$roomId);
			}

			//load and construct divisions with their codes
			$divisions = [];
			foreach(
				$this->dbConnection->query("SELECT * FROM roomdivision WHERE room_id=".$roomId)
				as $division
			){
				$divisionCode = $this->dbConnection->query(
					"SELECT code, is_admin FROM code WHERE division_id=".$division["division_id"]
				)[0];
				$divisions[] = new RoomDivision(
					$division["x_start"], $division["x_end"], $division["y_start"], $division["y_end"],
					new Code($divisionCode["is_admin"], $divisionCode["code"])
				);
			}

			//load and construct room codes
			$codes = [];
			foreach(
				$this->dbConnection->query(
					"SELECT * FROM code WHERE room_id=".$roomId." AND division_id IS NULL"
				) as $code
			){
				$codes[] = new Code($code["is_admin"], $code["code"]);
			}

			$this->rooms[$roomId] = new Room(
				$room["name"], $room["official"], $this->canvasStore->getCanvas($room["canvas_id"]),
				$room["pixel_set_delay"], $divisions, $codes
			);
		}
		return $this->rooms[$roomId];
	}

	/**
	 * Saves the full Room metadata AND canvas data to the Database.
	 *
	 * @param Room $room
	 * @return int The roomId for the given Room object in the database
	 */
	public function saveRoom(Room $room): int{
		if(($roomId = array_search($room, $this->rooms, true)) === false){
			$roomInsert = $this->dbConnection->prepare(
				"INSERT INTO room(name, canvas_id, official, pixel_set_delay) VALUES(?,?,?,?)"
			);
			try{
				$roomInsert->execute([
					$room->getRoomName(), $this->canvasStore->saveCanvas($room->getCanvas()),
					$room->isOfficial() ? "true" : "false", $room->getPixelSetDelay()
				]);
			}catch(PDOException $exception){
				if($exception->getCode() == 23505){ //(unique violation)
					throw new RoomNotManagedException("Given Room is not managed by this store!");
				}else{
					throw $exception;
				}
			}

			$roomId = (int) $this->dbConnection->getConnection()->lastInsertId("room_room_id_seq");
		}

		//Room update
		$roomUpdate = $this->dbConnection->prepare(
			"UPDATE Room SET name=?, official=?, pixel_set_delay=? WHERE room_id=".$roomId
		);
		$roomUpdate->execute([$room->getRoomName(), $room->isOfficial() ? "true" : "false", $room->getPixelSetDelay()]);

		//Code update
		// insert new/missing codes
		$insertCode = $this->dbConnection->prepare(
			"INSERT INTO code(room_id, code, is_admin) VALUES(?,?,?) ON CONFLICT DO NOTHING"
		);
		foreach($room->getCodes() as $code){
			$insertCode->execute([$roomId, $code->code, $code->isAdmin ? "true" : "false"]);
		}

		//Division update
		// insert new/missing divisions
		$insertRoomDivision = $this->dbConnection->prepare(
			"INSERT INTO roomdivision(room_id, x_start, y_start, x_end, y_end) VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING"
		);
		$insertRoomDivisionCode = $this->dbConnection->prepare(
			"INSERT INTO code(room_id, code, division_id) VALUES(?,?,?) ON CONFLICT DO NOTHING"
		);
		foreach($room->getDivisions() as $division){
			$insertRoomDivision->execute([$roomId, $division->xStart, $division->yStart, $division->xEnd, $division->yEnd]);
			$insertRoomDivisionCode->execute([
				$roomId, $division->code->code,
				$this->dbConnection->getConnection()->lastInsertId("roomdivision_division_id_seq")
			]);
		}

		//Update Canvas
		$this->canvasStore->saveCanvas($room->getCanvas());

		return $roomId;
	}

	public function listOfficialRooms(): array{
		return $this->dbConnection->query("SELECT room_id AS id, name FROM room WHERE official=TRUE");
	}

	public function deleteRoom(Room $room){
		$deleteRoom = $this->dbConnection->prepare("DELETE FROM public.canvas WHERE canvas_id=?"); //uses cascading
		$deleteRoom->execute([$this->canvasStore->getCanvasId($room->getCanvas())]);
		unset($this->rooms[$this->getRoomId($room)]);
	}
}