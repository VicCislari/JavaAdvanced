<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\room\exception;

use RuntimeException;

/** @author Hartmann */
class RoomNotFoundException extends RuntimeException{

}