<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\room\exception;

use RuntimeException;

/**
 * This is thrown when the room given to RoomStore->saveRoom is not known by the store, but is already in the database.
 * This could hint at multiple instances of RoomStore being used, or attempting to create a Room with an already
 * existing name.
 *
 * @author Hartmann
 */
class RoomNotManagedException extends RuntimeException{

}