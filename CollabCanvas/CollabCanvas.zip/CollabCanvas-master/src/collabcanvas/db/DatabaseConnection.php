<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\db;

use PDO;
use PDOException;
use PDOStatement;
use robske_110\Logger\Logger;
use RuntimeException;

/**
 * @author Hartmann
 *
 * Class for establishing a Database connection
 */
class DatabaseConnection{
	private PDO $connection;
	
	private string $host;
	private string $db;
	private string $username;
	private ?string $password;
	
	public function __construct(string $host, string $db, string $username, ?string $password = null){
		$this->host = $host;
		$this->db = $db;
		$this->username = $username;
		$this->password = $password;
		$this->connect();
	}
	
	public function connect(){
		try{
			$this->connection = new PDO(
				"pgsql:host=".$this->host.";dbname=".$this->db, $this->username, $this->password
			);
		}catch(PDOException $e){
			throw $this->handlePDOexception($e, "Failed to connect to db (check db connection params)");
		}
	}
	
	public function getConnection(): PDO{
		return $this->connection;
	}
	
	public function query(string $sql): bool|array{
		try{
			$res = $this->connection->query($sql);
		}catch(PDOException $e){
			throw $this->handlePDOexception($e, "Query ".$sql." failed");
		}
		return $res->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function prepare(string $sql): PDOStatement{
		try{
			$pdoStatement = $this->connection->prepare($sql);
		}catch(PDOException $e){
			throw $this->handlePDOexception($e, "Preparing query ".$sql." failed");
		}
		return $pdoStatement;
	}
	
	public function queryStatement(string $sql): PDOStatement{
		try{
			$pdoStatement = $this->connection->query($sql);
		}catch(PDOException $e){
			throw $this->handlePDOexception($e, "Running query ".$sql." failed");
		}
		return $pdoStatement;
	}
	
	public function handlePDOexception(PDOException $e, ?string $what = null): RuntimeException{
		Logger::var_dump($e->errorInfo, "errorInfo");
		return new RuntimeException(($what.": " ?? "").$e->getMessage()." [".$e->getCode()."]");
	}
}