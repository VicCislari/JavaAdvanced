/* Author: Brieger, Hartmann */

CREATE TABLE IF NOT EXISTS Canvas (
    canvas_id serial NOT NULL PRIMARY KEY,
    width integer NOT NULL,
    height integer NOT NULL,
    image_data bytea
);

CREATE TABLE IF NOT EXISTS Displayname (
    displayname_id serial NOT NULL PRIMARY KEY,
    displayname text NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS CanvasDisplayname (
    displayname_id integer NOT NULL REFERENCES Displayname(displayname_id) ON DELETE CASCADE,
    canvas_id integer NOT NULL REFERENCES Canvas(canvas_id) ON DELETE CASCADE,
    PRIMARY KEY (displayname_id, canvas_id),
    canvas_displayname_id smallint NOT NULL
);

CREATE TABLE IF NOT EXISTS Room (
    room_id serial NOT NULL PRIMARY KEY,
    name text NOT NULL UNIQUE,
    canvas_id integer NOT NULL REFERENCES Canvas(canvas_id) ON DELETE CASCADE,
    pixel_set_delay integer NOT NULL,
    official boolean NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS RoomDivision (
    division_id serial NOT NULL UNIQUE,
    room_id integer NOT NULL REFERENCES Room(room_id) ON DELETE CASCADE,
    x_start integer NOT NULL,
    y_start integer NOT NULL,
    x_end integer NOT NULL,
    y_end integer NOT NULL,
    PRIMARY KEY (room_id, x_start, y_start, x_end, y_end)
);

CREATE TABLE IF NOT EXISTS Code (
    room_id serial NOT NULL REFERENCES Room(room_id) ON DELETE CASCADE,
    code character(6) NOT NULL,
    PRIMARY KEY (room_id, code),
    division_id integer REFERENCES RoomDivision(division_id) ON DELETE CASCADE,
    is_admin boolean NOT NULL DEFAULT FALSE
);
