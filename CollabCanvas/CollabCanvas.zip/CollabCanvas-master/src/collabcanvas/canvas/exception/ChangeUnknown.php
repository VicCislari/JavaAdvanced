<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas\exception;

use RuntimeException;

/** @author Hartmann */
class ChangeUnknown extends RuntimeException{

}