<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas;

use robske_110\Logger\Logger;
use RuntimeException;

/**
 * @author Hartmann
 */
class Canvas{
	private const PIXEL_DATA_LEN = 4;

	/**
	 * The Image Data byte array
	 * It contains all pixel data. For each Pixel the following data is saved:
	 * [R uint1 | G uint1 | B uint1 | LastEditedBy uint1]
	 * The pixel data is arranged in x-rows. Practically a two-dimensional array addressed using one dimension.
	 * 3x2 [width x height] imageData layout:
	 * 0     1     2     3     4     5      PixelId (multiply by PIXEL_DATA_LEN to get byte offset / address)
	 * (0,0) (1,0) (2,0) (0,1) (1,1) (2,1)  Pixel (x,y)
	 *
	 * Note on the data type:
	 * PHP doesn't have native arrays. Since we need a byte array anyway, using a string is the most sensible option.
	*/
	private string $imageData;

	public function __construct(
		private int $width,
		private int $height,
		string $imageData = ""
	){
		if(strlen($imageData) === 0){
			$this->imageData = str_repeat("\xff\xff\xff\0", $this->width*$this->height);
		}elseif(strlen($imageData) === $this->height*$this->width*self::PIXEL_DATA_LEN){
			$this->imageData = $imageData;
		}else{
			throw new RuntimeException("Invalid imageData");
		}
	}

	public function getWidth(): int{
		return $this->width;
	}

	public function getHeight(): int{
		return $this->height;
	}

	private function getPixelPos(int $x, int $y): int{
		return ($x * self::PIXEL_DATA_LEN) + ($y * $this->width * self::PIXEL_DATA_LEN);
	}

	/**
	 * Checks if the given x and y coordinates are valid and in this canvas.
	 *
	 * @param int $x
	 * @param int $y
	 *
	 * @throws RuntimeException Thrown when the pixels are invalid or not on the canvas.
	 */
	private function checkCoordinates(int $x, int $y){
		if($x < 0 || $y < 0){
			throw new RuntimeException("Invalid coordinates!");
		}
		if($x >= $this->width || $y >= $this->height){
			throw new RuntimeException("Given coordinates are not on canvas (".$this->width."x".$this->height.")!");
		}
	}

	public function setPixel(Pixel $pixel){
		$this->checkCoordinates($pixel->x, $pixel->y);
		Logger::log(
			"Setting pixel at x=".$pixel->x." y=".$pixel->y.
			": r=".$pixel->red." g=".$pixel->green." b=".$pixel->blue." lEB=".$pixel->lastEditedBy
		);
		$pixelPos = $this->getPixelPos($pixel->x, $pixel->y);
		Logger::debug("pixelPos=".$pixelPos);
		/* chr() converts a number to a single char (single byte) string */
		$this->imageData[$pixelPos++] = chr($pixel->red);
		$this->imageData[$pixelPos++] = chr($pixel->green);
		$this->imageData[$pixelPos++] = chr($pixel->blue);
		$this->imageData[$pixelPos] = chr($pixel->lastEditedBy);
	}

	public function getPixel(int $x, int $y): Pixel{
		$this->checkCoordinates($x, $y);
		$pixelPos = $this->getPixelPos($x, $y);
		return new Pixel(
			$x, $y,
			ord($this->imageData[$pixelPos++]),
			ord($this->imageData[$pixelPos++]),
			ord($this->imageData[$pixelPos++]),
			ord($this->imageData[$pixelPos])
		);
	}

	/**
	 * @return string The raw image data byte array
	 */
	public function getImageData(): string{
		return $this->imageData;
	}

	/**
	 * Returns a formatted hexdump of the image data, useful for debugging.
	 *
	 * @return string
	 */
	public function debugDumpImageData(): string{
		return chunk_split(
			chunk_split(bin2hex($this->imageData), self::PIXEL_DATA_LEN*2, " "),
			$this->width*(self::PIXEL_DATA_LEN * 2 + 1)
		);
	}

	/**
	 * Returns better debug info that php can use to describe this object.
	 *
	 * @return array
	 */
	public function __debugInfo(): array{
		return [
			"width" => $this->width,
			"height" => $this->height,
			"imageDataLength" => strlen($this->imageData),
			"imageData" => $this->debugDumpImageData()
		];
	}
}