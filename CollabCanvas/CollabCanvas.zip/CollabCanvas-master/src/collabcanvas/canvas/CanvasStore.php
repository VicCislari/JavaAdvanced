<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas;

use Amp\Loop;
use PDO;
use robske_110\collabcanvas\db\DatabaseConnection;
use robske_110\Logger\Logger;
use RuntimeException;

/**
 * The CanvasStore class manages Canvas objects. It provides mechanisms to get Room objects by their database id and
 * write/read Canvas objects to/from the database. It includes a Canvas object cache.
 *
 * @author Hartmann
 */
class CanvasStore{
	/** @var Canvas[] */
	private array $canvases = [];

	public function __construct(private DatabaseConnection $dbConnection, private DisplayNameStore $displayNameStore){
	}

	public function getDisplaynameStore(): DisplayNameStore{
		return $this->displayNameStore;
	}

	public function getCanvasId(Canvas $canvas): int{
		if(($canvasId = array_search($canvas, $this->canvases, true)) === false){
			throw new RuntimeException("Could not find given canvas object!");
		}
		return $canvasId;
	}

	public function getCanvas(int $canvasId): Canvas{
		if(!isset($this->canvases[$canvasId])){
			//load and construct canvas
			$canvas = $this->dbConnection->query("SELECT * FROM canvas WHERE canvas_id=".$canvasId)[0];

			$this->canvases[$canvasId] =
				new Canvas($canvas["width"], $canvas["height"], fread($canvas["image_data"], 4*1000*1000));
		}
		return $this->canvases[$canvasId];
	}

	private array $lastWrite = [];

	public function deferredSave(Canvas $canvas){
		$id = spl_object_id($canvas);
		Loop::delay(10000, function() use ($id, $canvas){
			if(($this->lastWrite[$id] ?? 0) < time()-9){ //write every ten seconds
				$this->saveCanvas($canvas);
				$this->lastWrite[$id] = time();
				Logger::log("saved canvas!");
			}
		});
	}

	/**
	 * Saves the full data in a Canvas to the Database
	 * @param Canvas $canvas The Canvas object to be saved.
	 * @return int The canvasId for the given canvas in the database
	 * IMPORTANT: DO NOT CALL THIS ON OBJECTS NOT OBTAINED FROM getCanvas! DOING SO WILL LEAD TO DUPLICATE DB ENTRIES!
	 */
	public function saveCanvas(Canvas $canvas): int{
		if(($canvasId = array_search($canvas, $this->canvases, true)) === false){
			//Canvas insertion
			$canvasStatement = $this->dbConnection->prepare(
				"INSERT INTO canvas(width, height, image_data) VALUES(?,?,?)"
			);
		}else{
			//Canvas update
			$canvasStatement = $this->dbConnection->prepare(
				"UPDATE Canvas SET width=?, height=?, image_data=? WHERE canvas_id=".$canvasId
			);
		}

		$canvasStatement->bindValue(1, $canvas->getWidth(), PDO::PARAM_INT);
		$canvasStatement->bindValue(2, $canvas->getHeight(), PDO::PARAM_INT);
		$canvasStatement->bindValue(3, $canvas->getImageData(), PDO::PARAM_LOB);
		$canvasStatement->execute();

		if($canvasId === false){
			$canvasId = (int) $this->dbConnection->getConnection()->lastInsertId("canvas_canvas_id_seq");
			$this->canvases[$canvasId] = $canvas;
		}

		return $canvasId;
	}
}