<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas;

use Exception;
use robske_110\collabcanvas\canvas\exception\ChangeUnknown;
use robske_110\Logger\Logger;

/**
 * Tracks changes done to the Canvases in-memory
 * Provides the base for the differential update mechanism
 * @author Hartmann
 */
class CanvasChangeTracker{
	private $changes = [];

	/** @var int Contains the unix timestamp of the server start. Used for building updateIds */
	private int $serverStart;

	public function __construct(){
		if(PHP_INT_SIZE !== 8){
			throw new Exception("Can only run on 64bit systems!");
		}
		$this->serverStart = time(); //set serverStart to current time
	}

	/**
	 * Executes a setPixel call on the canvas and tracks the change as an update
	 * @param Canvas $canvas The Canvas to set a pixel in
	 * @param Pixel $pixel The pixel to be set
	 */
	public function setPixel(Canvas $canvas, Pixel $pixel){
		$updateId = $this->getUpdateId($canvas);

		$this->changes[spl_object_id($canvas)][] = [
			"updateId" => $updateId,
			"x" => $pixel->x, "y" => $pixel->y,
			"r" => $pixel->red, "g" => $pixel->green, "b" => $pixel->blue,
			"lastEditedBy" => $pixel->lastEditedBy
		];

		$canvas->setPixel($pixel);
		//Logger::var_dump($this->changes);
	}

	private function debugUpdateId(int $updateId){
		echo("srvStart    :");
		Logger::var_dump($this->serverStart);
		echo("srvStart uId:");
		Logger::var_dump(($updateId >> 32 & ((1<<32)-1)));
		Logger::var_dump($updateId & ((1<<32)-1), "updateCounter");
		echo("updateId bin:");
		echo(chunk_split(trim("0".decbin($updateId)), 32, " ").PHP_EOL);
	}

	/**
	 * @param Canvas $canvas The canvas to get a changeList for
	 * @param int $updateId The last known updateId
	 *
	 * @return array The changes done to the canvas since the updateId
	 * @throws ChangeUnknown Thrown when the updateId is not known and no full changeList could be constructed
	 */
	public function getChangesAfter(Canvas $canvas, int $updateId): array{
		//$this->debugUpdateId($updateId);
		if(
			($updateId >> 32 & ((1<<32)-1)) !== $this->serverStart //php shifts the sign into the number
		){
			throw new ChangeUnknown("Change unknown!"); //Server was restarted since client requested canvas
		}

		if(isset($this->changes[spl_object_id($canvas)])){
			return array_slice($this->changes[spl_object_id($canvas)], $updateId & ((1<<32)-1));
		}else{
			return []; //No changes known for given canvas
		}
	}

	/**
	 * @param Canvas $canvas
	 * @return int Returns the next updateId for the given canvas
	 */
	public function getUpdateId(Canvas $canvas){
		if(!isset($this->changes[spl_object_id($canvas)])){
			return $this->serverStart << 32;
		}
		return ($this->serverStart << 32) + count($this->changes[spl_object_id($canvas)]);
	}
}