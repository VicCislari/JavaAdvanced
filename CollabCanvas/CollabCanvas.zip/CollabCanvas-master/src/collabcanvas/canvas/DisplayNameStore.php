<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas;

use PDO;
use PDOStatement;
use robske_110\collabcanvas\canvas\exception\DisplayNameNotFoundException;
use robske_110\collabcanvas\db\DatabaseConnection;
use robske_110\Logger\Logger;

/**
 * The DisplayNameStore class manages displayNames.
 * DisplayNames have a local (canvas) id and a global id. The local id is only valid in conjunction with a canvas id.
 * (This is done to be able to keep the size of the lastEditedBy field low in the canvas image data.)
 * The class provides mechanisms to get displayNames by their global id and their local id and writes/reads them to/from
 * the database. It includes a displayName cache.
 *
 * @author Hartmann, Ermis
 */
class DisplayNameStore{
	/**
	 * Cache only, does not contain all entries.
	 * @var array [int globalDisplayNameId => string displayName]
	 */
	private array $globalDisplayNameCache = [];

	/**
	 * @var array [int room_id => [int globalDisplayNameId]]
	 */
	private array $canvasDisplayNames = [];

	private PDOStatement $findGlobal;
	private PDOStatement $findLocal;

	public function __construct(private DatabaseConnection $dbConnection){
		$this->findGlobal = $this->dbConnection->prepare(
			"SELECT displayname_id FROM displayname WHERE displayname=?"
		);
		$this->findLocal = $this->dbConnection->prepare(
			"SELECT canvas_displayname_id FROM canvasdisplayname WHERE canvas_id = ? AND displayname_id = ?"
		);
	}

	/**
	 * @param int $canvasId
	 * @return int[] [int localId => int displayName]
	 */
	public function getLocalDisplayNames(int $canvasId): array{
		if(isset($this->canvasDisplayNames[$canvasId])){
			return $this->canvasDisplayNames[$canvasId];
		}

		//fetch displaynames from db
		$displayNames = $this->dbConnection->query(
			"SELECT displayname_id FROM canvasdisplayname WHERE canvas_id=".$canvasId." ORDER BY canvas_displayname_id"
		);
		if(empty($displayNames)){
			return []; //do not cache empty arrays
		}
		$displayNameArray = [];
		foreach($displayNames as $id => $info){
			$displayNameArray[$id+1] = (int) $info["displayname_id"];
		}

		return $this->canvasDisplayNames[$canvasId] = $displayNameArray;
	}

	public function getDisplayNameByGlobal(int $globalId): string{
		if(isset($this->globalDisplayNameCache[$globalId])){
			return $this->globalDisplayNameCache[$globalId];
		}
		return $this->globalDisplayNameCache[$globalId] = $this->dbConnection->query(
			"SELECT displayname FROM displayname WHERE displayname_id=".$globalId
		)[0]["displayname"] ?? throw new DisplayNameNotFoundException("Could not find displayname!");
	}

	public function getDisplayNameByLocal(int $canvasId, int $localId): string{
		if(isset($this->canvasDisplayNames[$canvasId][$localId])){
			return $this->getDisplayNameByGlobal($this->canvasDisplayNames[$canvasId][$localId]);
		}
		return $this->getDisplayNameByGlobal(
			$this->getLocalDisplayNames($canvasId)[$localId] ??
			throw new DisplayNameNotFoundException("Could not find displayName!")
		);
	}

	public function addDisplayName(int $canvasId, string $displayName){
		$this->findGlobal->execute([$displayName]);
		//check if displayName exists globally, if not insert it
		if(($globalId = $this->findGlobal->fetch(PDO::FETCH_ASSOC)["displayname_id"] ?? null) === null){
			$insertGlobal = $this->dbConnection->prepare(
				"INSERT INTO displayname(displayname) VALUES(?)"
			);
			$insertGlobal->execute([$displayName]);
			$globalId = $this->dbConnection->getConnection()->lastInsertId("displayname_displayname_id_seq");
		}
		$globalId = (int) $globalId;
		Logger::var_dump($globalId, "gId");
		$this->globalDisplayNameCache[$globalId] = $displayName;

		if(!in_array($displayName, $this->getLocalDisplayNames($canvasId))){
			$insertCanvas = $this->dbConnection->prepare(
				"INSERT INTO canvasdisplayname(displayname_id, canvas_id, canvas_displayname_id) VALUES (?,?,?)"
			);
			$localId = count($this->getLocalDisplayNames($canvasId)) + 1;
			$insertCanvas->execute([$globalId, $canvasId, $localId]);
			$this->canvasDisplayNames[$canvasId][$localId] = $globalId;
		}
	}

	public function getLocalIdForDisplayName(int $canvasId, string $displayName): int{
		$this->findGlobal->execute([$displayName]);
		$globalId = $this->findGlobal->fetch(PDO::FETCH_ASSOC)["displayname_id"] ??
			throw new DisplayNameNotFoundException("Could not find displayName (globally)");
		$this->findLocal->execute([$canvasId, $globalId]);
		return (int) ($this->findLocal->fetch(PDO::FETCH_ASSOC)["canvas_displayname_id"] ??
			throw new DisplayNameNotFoundException("Could not find displayName (locally, in canvas)"));
	}

	public function createOrGetLocalIdForDisplayName(int $canvasId, string $displayName){
		try{
			return $this->getLocalIdForDisplayName($canvasId, $displayName);
		}catch(DisplayNameNotFoundException){
			$this->addDisplayName($canvasId, $displayName);
			return $this->getLocalIdForDisplayName($canvasId, $displayName);
		}
	}
}