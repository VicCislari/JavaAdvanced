<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\canvas;

use RuntimeException;

/**
 * Immutable object representing a single Pixel
 *
 * @author Hartmann
 */
class Pixel{
	public function __construct(
		public readonly int $x,
		public readonly int $y,
		public readonly int $red,
		public readonly int $green,
		public readonly int $blue,
		public readonly int $lastEditedBy
	){
		if($x < 0 || $y < 0){
			throw new RuntimeException("Invalid coordinates!");
		}
		if($this->red < 0 || $this->red > 255 || $this->green < 0 || $this->green > 255 || $this->blue < 0 || $this->blue > 255){
			throw new RuntimeException("Invalid color!");
		}
		if($this->lastEditedBy < 0 || $this->lastEditedBy > 255){
			throw new RuntimeException("lastEditedBy out of range! (0-255)");
		}
	}

	public function getRed(): int{
		return $this->red;
	}

	public function getGreen(): int{
		return $this->red;
	}

	public function getBlue(): int{
		return $this->blue;
	}

	public function getColorAsArray(): array{
		return [$this->red, $this->green, $this->blue];
	}
}