<?php
declare(strict_types=1);

namespace robske_110\collabcanvas\auth;

use RuntimeException;

/**
 * Immutable class representing an access code, capable of generating one and checking equality safely.
 *
 * @author Hartmann
 */
class Code{
	public readonly string $code;

	const CODE_LEN = 6;

	public function __construct(public readonly bool $isAdmin, ?string $code = null){
		if($code === null){
			$this->code = $this->generateCode(self::CODE_LEN);
		}elseif(strlen($code) > 0){
			$this->code = $code;
		}else{
			throw new RuntimeException("Codes must at least be one character long!");
		}
	}

	public function check(string $code): bool{
		return hash_equals($this->code, $code); //timing-attack safe string comparison
	}

	private function generateCode(int $length){
		$characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$max = mb_strlen($characters, '8bit') - 1;
		$code = "";
		for($i = 0; $i < $length; ++$i){
			$code .= $characters[random_int(0, $max)];
		}
		return $code;
	}
}