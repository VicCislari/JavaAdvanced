#!/bin/bash

/usr/src/CollabCanvas/start.sh --ignore-env-file