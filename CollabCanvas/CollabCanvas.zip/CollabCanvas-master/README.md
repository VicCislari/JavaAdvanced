# CollabCanvas

A collaborative Canvas application.

## Running
### with Docker
1. Copy or rename `docker/.env.example` to `docker/.env`
2. Adjust value in `docker/.env` as needed
3. Run the command `docker-compose up` in the `docker` subdirectory.
### outside of docker
Prerequisites: php (8.1 minimum) with pdo-psql and ext-pcntl
1. Set up a postgresql db (you can also use the instance running in docker)
2. Copy or rename `.env.example` to `.env`.
3. Adjust values in `.env` as needed
4. Run start.sh