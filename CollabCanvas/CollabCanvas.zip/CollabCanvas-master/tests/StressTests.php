<?php
declare(strict_types=1);

/**
 * @author Hartmann
 */
for($i = 999; $i >= 980; --$i){
	exec("php ".__DIR__."/StressTest.php ".$i." >/dev/null 2>/dev/null &");
}
sleep(150);