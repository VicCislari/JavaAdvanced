<?php
declare(strict_types=1);

use robske_110\Logger\Logger;

/**
 * @author Hartmann
 */

require("../vendor/autoload.php");
Logger::init();

$cW = new CurlWrapper();

const URL = "https://collabcanvas.duckdns.org/api/";

var_dump(
$cW->postRequest(URL."room/3/auth", json_encode(["code" => "dlnsrc", "displayName" => "StressTester"]))
); //["r" => 0x02, "g" => 0xbe, "b" => 0x01, "x" => $x, "y" => 999-0]
$start = microtime(true);
for($x = 0; $x < 1000; $x++){
	$cW->postRequest(
		URL."room/3/canvas/pixel",
		json_encode(["r" => 0x02, "g" => 0xbe, "b" => 0x01, "x" => $x, "y" => (int) $argv[1]]), [], "PUT"
	);
}
echo("Took ". (microtime(true)-$start)."s");

/* ------------------------------------------------------------------------------------------------------------------ */

/**
 * @author Hartmann
 * Open source, not exclusively written for this project
 */
class CurlWrapper{
	protected CurlHandle $ch;

	public function setCurlOption(int $curlOption, $value){
		if(!curl_setopt($this->ch, $curlOption, $value)){
			throw new Exception("Failed to set curl option ".$curlOption." to ".print_r($value, true));
		}
	}

	public function __construct($enableVerbose = false){
		$this->ch = curl_init();
		$this->setCurlOption(CURLOPT_VERBOSE, $enableVerbose);
		$this->setCurlOption(CURLOPT_COOKIEFILE, ""); //enable cookie handling
		$this->setCurlOption(CURLOPT_FOLLOWLOCATION, true);
	}

	private static function parseHeaderLine(string $headerLine): ?array{
		$colonPos = strpos($headerLine, ":");
		if($colonPos === false){
			return null;
		}
		$name = substr($headerLine, 0, $colonPos);
		return [$name, substr($headerLine, $colonPos+2)];
	}

	protected function onHeaderEntry(string $headerEntryName, string $headerEntryValue){

	}

	protected function onCookie(string $cookieName, string $cookieContent){

	}

	private function curlHeader(CurlHandle $ch, string $headerLine){
		//Logger::debug("Curl header: ".$headerLine);
		$headerEntry = self::parseHeaderLine($headerLine);
		if($headerEntry !== null){
			$this->onHeaderEntry(...$headerEntry);
			if(strtolower($headerEntry[0]) == "set-cookie"){
				$cookieStr = $headerEntry[1];
				$posAssign = strpos($cookieStr, "=");
				$cookieName = substr($cookieStr, 0, $posAssign);
				$posSemicolon = strpos($cookieStr, ";");
				$cookieContent = substr($cookieStr, $posAssign+1, $posSemicolon-$posAssign-1);
				$this->onCookie($cookieName, $cookieContent);
			}
		}
		return strlen($headerLine);
	}

	/**
	 * Performs curl_exec with returntransfer and the curlHeader callbacks on the CURL resource $this->ch
	 *
	 * @return string Returns the result
	 */
	protected function curl_exec(): string{
		$this->setCurlOption(CURLOPT_RETURNTRANSFER, true);
		$this->setCurlOption(CURLOPT_HEADERFUNCTION, [$this, "curlHeader"]);
		$result = curl_exec($this->ch);
		if($result === false){
			if(curl_errno($this->ch)){
				$curlError = new CurlError("A curl request failed: ".curl_error($this->ch)." [".curl_errno($this->ch)."]");
				$curlError->curlErrNo = curl_errno($this->ch);
				throw $curlError;
			}else{
				throw new Exception("A curl request failed with an unknown reason.");
			}
		}
		return $result;
	}

	public function getRequest(string $url, array $fields = [], array $header = []){
		Logger::debug("GET request to ".$url.HTTPUtils::makeFieldStr($fields));
		curl_setopt($this->ch, CURLOPT_POST, false);
		curl_setopt($this->ch, CURLOPT_URL, $url.HTTPUtils::makeFieldStr($fields));
		#$header[] = "Connection: keep-alive";
		if(!empty($header)){
			Logger::var_dump($header, "header");
		}
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
		return $this->curl_exec();
	}

	public function postRequest(string $url, $body, array $header = [], $reqType = "POST"){
		Logger::debug("POST request to ".$url." body:".print_r($body, true));
		curl_setopt($this->ch, CURLOPT_POST, true);
		curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, $reqType);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $body);
		curl_setopt($this->ch, CURLOPT_URL, $url);
		#$header[] = "Connection: keep-alive";
		if(!empty($header)){
			Logger::var_dump($header, "header");
		}
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
		return $this->curl_exec();

	}

	public function getCh(){
		return $this->ch;
	}

	public function __destruct(){
		curl_close($this->ch);
	}
}

/**
 * @author Hartmann
 * Open source, not exclusively written for this project
 */
class CurlError extends RuntimeException{
	public int $curlErrNo;
}