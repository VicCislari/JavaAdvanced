<?php
declare(strict_types=1);

use robske_110\collabcanvas\canvas\Canvas;
use robske_110\collabcanvas\canvas\Pixel;
use robske_110\Logger\Logger;

require("../vendor/autoload.php");
Logger::init();

$canvas = new Canvas(10, 10);

var_dump($canvas);

$canvas->setPixel(9, 9, new Pixel(255, 0, 255, 1));

echo($canvas->debugDumpImageData());

var_dump($canvas->getPixel(2, 2));