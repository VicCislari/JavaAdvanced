/*
 * @author Hartmann, Herbst, Brieger
 */

// Edit
//global variables, accessible from all js-scripts running on clients site
let username = null;
let code = null;
let divisionId = null;
let showDivision = true;
let loggedIn = false;
let adminCode = null;
let official = null;
let deleteState = null;
let showDivisionsButton = document.getElementById("show-Division-Border");
let logoutButton = document.getElementById("logout");
let editButton = document.getElementById("edit");
let loginForm = document.getElementById("login-form");
let loginSubm = document.getElementById("login-form-confirm");
let inputUname = document.getElementById("username");
let inputCode = document.getElementById("roomcode");
let adminForm = document.getElementById("admin-form");
let roomname = document.getElementById("roomname");
let inputOfficialState = document.getElementById("official-state");
let adminSubm = document.getElementById("admin-form-confirm");
let deleteRoomButton = document.getElementById("delete-room");
let deleteConfirmTemplate = document.getElementById("delete-confirm");
let abortButton = document.getElementById("abort-button");
let backgroundOL = document.getElementById("backgroundOverlay");

/*
* enables Overlay, that blocks clicks on background and unintended keyboard actions, while pop-ups are shown (adds deactivation EventListener)
 */
function enableOverlay(){
    backgroundOL.style.display = "block";
    backgroundOL.addEventListener('click', (e) => {
        disableOverlay();

    })
    keyHandlingActivated = false;
}

/*
* disables Overlay, that blocks clicks on background and unintended keyboard actions, when pop-ups get closed
* */
function disableOverlay(){
    backgroundOL.style.display = "none";
    if(loginForm.style.display !== "none"){
        loginForm.style.display = "none";
        clearLoginInput();
    }else{
        adminForm.style.display = "none";
    }
    keyHandlingActivated = true;
}

/*
* function let the logout button disappear
* */
function disableLogoutButton(){
    logoutButton.style.display='none';
}

/*
* function let the logout button appear and adds logout functionality to it
* */
function enableLogoutButton(){
    logoutButton.style.display='block';

    logoutButton.addEventListener('click',async(e) => {
        await fetch(
            `/api/logout`,
            {
                method: 'POST'
                });
        location.reload();
    });
}

/*
* function unsets the login information input fields
* */
function clearLoginInput(){
    inputUname.value = null;
    inputCode.value = null;
}

/*
* function enables access to admin menu on canvas page and adds admin functionality (+ no timeout)
* */
function enableAdminOptions(){
    roomname.addEventListener('dblclick', (e) => {
        enableOverlay();
        adminForm.style.display = "flex";


        if(room.official === true){
            inputOfficialState.checked = true;
        }
    });

    setTimerPrivilege();
}



/*
* function trys to get old session data to resume an previous session
* */
async function tryResumeSession(){
    let response = await fetch(
        `/api/room/${roomId}/authinfo`);

    let responseContent = await response.json();

    if (response.status === 200){//configuring session with found information
        username = responseContent.displayName;
        editButton.innerHTML = username;
        loggedIn = true;
        editButton.style.cursor = "auto";

        divisionId = responseContent.divisionId;

        if (responseContent.isAdmin){
            enableAdminOptions();
        }
        enableLogoutButton();
    }else{
        //if no session fetchable activate login form
        editButton.addEventListener('click', (e) => {
            if(!loggedIn){
                enableOverlay();
                loginForm.style.display = "flex";
            }
        });
    }
}

/*
* function adds login functionality to its button
* */
loginSubm.addEventListener('click', async(e) => {
    username = inputUname.value;
    if(username === ""){
        alert("Anzeigename darf nicht leer sein!");
        return;
    }
    code = inputCode.value;
    let response;
    if(code.length > 6){
        response = await fetch(
            `/api/system/auth`,
            {
                method: 'POST', headers: new Headers({'content-type': 'application/json'}),
                body: JSON.stringify({
                    "code": code,
                })
            }
        );
    }else{
        response = await fetch(
            `/api/room/${roomId}/auth`,
            {
                method: 'POST', headers: new Headers({'content-type': 'application/json'}),
                body: JSON.stringify({
                    "code": code,
                    "displayName": username
                })
            },
        );
    }
    let responseContent = await response.json();

    //Response evaluating
    if(response.status !== 200){

        switch(response.status){
            case 401:
                alert("Dieser Code ist falsch!");
                break;
            case 403:
                alert("Administratorname kann nicht als Anzeigename verwendet werden!");
                break;
            default:
                alert("Unknown error, please try again!");
                break;
        }

        clearLoginInput();
        return;
    }

    if(responseContent.isAdmin === true){
        enableAdminOptions();
        if(responseContent.displayName !== undefined){
            username = responseContent.displayName;
        }
    }
    if(responseContent.divisionId !== undefined){
        divisionId = responseContent.divisionId;
    }


    loginForm.style.display = "none";
    editButton.innerHTML = username;
    loggedIn = true;
    editButton.style.cursor = "auto";
    enableLogoutButton();
    disableOverlay();
});


/*
* function trys to patch room if admin hit the after changes in admin overlay, adds functionality to let overlay disappear
* */
adminSubm.addEventListener('click', async(e) => {
    official = inputOfficialState.checked;

    let response = await fetch(
        `/api/room/${roomId}`,
        {
            method: 'PATCH', headers: new Headers({'content-type': 'application/json'}),
            body: JSON.stringify({"official": official})
        }
    );
    if(response.status !== 200){
        //Something went wrong
        switch(response.status){
            case 400:
                alert("Ungültige Parameter!");
                break;
            case 401:
                alert("Nicht authentifiziert!");
                break;
            case 403:
                alert("Sie sind kein Master!");
                break;
            case 404:
                alert("Raum nicht gefunden!");
                break;
            default:
                alert("Something went wrong!");
        }
        return;
    }

    adminForm.style.display = "none";
    location.reload();
});

/*
* function aborts room deletion request on client side
* */
abortButton.addEventListener('click', (e) => {
    deleteState = 0;
    if(document.getElementById("delete-confirmation-button") != null){
        document.getElementById("delete-confirmation-button").remove();
    }
    adminForm.style.display = "none";
});

/*
* function adds room deletion functionality to delete button
* */
deleteRoomButton.addEventListener('click', (e) => {
    if(deleteState != 1){
        let element = deleteConfirmTemplate.content.cloneNode(true);
        document.getElementById("delete-room").append(element);


        document.getElementById("delete-confirmation-button").addEventListener('click', async(e) => {
            let response = await fetch(
                `/api/room/${roomId}`,
                {method: 'DELETE'}
            );
            if(response.status !== 200){
                //Something went wrong
                if(response.status === 401){
                    //maybe room not found
                    alert("Nicht autorisiert!");
                }else{
                    //maybe no right for changes
                    alert("Ggf. haben sie nicht die benötigten Berechtigungen!");
                }
            }else{
                alert("Löschen erfolgreich!");
                window.location = "/index.html";
            }
        });
        deleteState = 1;
    }

});


/*
* function sets state if division drawing is activated and triggers new drawing
* */
showDivisionsButton.addEventListener('click', (e) => {
    showDivision = showDivisionsButton.checked;
    draw();
});

//initial run
disableLogoutButton();
tryResumeSession();



