/**
 * @author Brieger, Hartmann
 */

/*
 * Room object with room specific information
 */
class Room{
    constructor(name, official, divisions, delay, canvas){
        this.name = name;
        this.official = official;
        this.divisions = divisions;
        this.delay = delay;
        this.canvas = canvas;
    }
}

/*
 * Gets the information for a given room
 */
async function fetchRoomInformation(){
    let response = await fetch(`/api/room/${roomId}`);
    if(response.status !== 200){
        if(response.status === 404){
            alert("Dieser Raum wurde nicht gefunden. Bitte kehre zur Startseite zurück und gebe einen anderen Raumnamen ein.");
        }else{
            alert("Unbekannter Fehler. Bitte kehre zur Startseite zurück!");
        }
        return false;
    }else{
        return response.json();
    }
}

/*
* Extracts the roomID from the URL
* */
const urlParams = new URLSearchParams(window.location.search);
const roomId = parseInt(urlParams.get("roomID"));

let room;
/*
* Fetches information from selected room into room object asynchronously
* */
async function getRoomInformation(){
    let response = await fetchRoomInformation();
    room = new Room(
        response.roomName,
        response.official,
        response.divisions,
        response.pixelSetDelay,
        {width: response.canvas.width, height: response.canvas.height}
    );
    division = room.divisions;
}

/*
 * Change name of the displayed room
 */
function changeDisplayedRoomName(name){
    document.getElementById("roomname").textContent = name;
}

/*
 * Shows the verfied sign after the roomname in the navigation bar
 */
function showVerfiedSign(){
    let element = document.querySelector("#verified").content.cloneNode(true);
    document.querySelector("#roomname").append(element);
}

/*
 * activates information fetching and triggers page customization (function to wait for asynchronous feedback)
 */
async function loadAndDisplayRoomInformation(){
    await getRoomInformation();
    if(typeof room.name != 'undefined'){
        changeDisplayedRoomName(room.name);
    }
    if(room.official === true){
        showVerfiedSign();
    }

}

/*
* final execution
* */
loadAndDisplayRoomInformation();