/**
 * @author Schatz
*/

$(document).ready(function () {
    // Hide form elements if website loaded
    $('#canvasDivisionDiv').hide()
    $('#codeCopiedText').hide()

    // For enabling bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl){
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // If submit modal gets closed, reload the form site
    $('#formSubmitModal').on('hidden.bs.modal', function () {
        location.reload()
    })

    // Sets hyper reference back to homepage for back to homepage button within submit modal
    $('#backToHomepageButton').on("click",function () {
        window.location.href = "index.html";
    })

    $('#codesClipboardButton').on("click", function () {
        // Clipboard api does not work if user is not connected over https or over localhost to the website
        navigator.clipboard.writeText($('#codesText').val())
            .then(() => { // If copying to clipboard was successful
                $('#codeCopiedText').text("Zugangscodes erfolgreich in Zwischenablage kopiert!")
                    .show()

                // Let text disappear after 2 seconds
                window.setTimeout(function () {
                    $('#codeCopiedText').hide()
                }, 2000)
            })
            .catch(() => { // if copying to clipboard was not successful
                $('#codeCopiedText').text("Zugangscodes konnte nicht in Zwischenablage kopiert werden!")
                    .show()

                // Let text disappear after 2 seconds
                window.setTimeout(function () {
                    $('#codeCopiedText').hide()
                }, 2000)
            })

    })

    $('#adminCodesClipboardButton').on("click", function () {
        // Clipboard api does not work if user is not connected over https or over localhost to the website
        navigator.clipboard.writeText($('#adminCodesText').val())
            .then(() => { // If copying to clipboard was successful
                $('#adminCodesCopiedText').text("Zugangscode erfolgreich in Zwischenablage kopiert!")
                    .show()

                // Let text disappear after 2 seconds
                window.setTimeout(function () {
                    $('#adminCodesCopiedText').hide()
                }, 2000)
            })
            .catch(() => { // if copying to clipboard was not successful
                $('#adminCodesCopiedText').text("Zugangscode konnte nicht in Zwischenablage kopiert werden!")
                    .show()

                // Let text disappear after 2 seconds
                window.setTimeout(function () {
                    $('#adminCodesCopiedText').hide()
                }, 2000)
            })

    })

    // Change canvas width and height field labels and show divisions input field if the room mode is teamcanvas
    $('#roomMode').on("change",function () {
        const selection = $(this).val();
        switch (selection) {
            case "Team":
                $('#canvasDivision').attr('required', true)
                    .attr('min', "2")
                $('#canvasDivisionDiv').show()
                // Changes canvas measurements label to division measurements
                $('#canvasWidthLabel').text('Abschnittsbreite')
                $('#canvasHeightLabel').text('Abschnittshöhe')
                break;
            case "Collab":
                $('#canvasDivision').attr('required', false)
                    .removeAttr('min')
                $('#canvasDivisionDiv').hide()
                // Changes canvas measurements label back to default
                $('#canvasWidthLabel').text('Canvasbreite')
                $('#canvasHeightLabel').text('Canvashöhe')
                break;
        }
    });

    // Unmark roomname field if the field is marked invalid
    $("#roomName").on("change", function() {
        if(document.getElementById("roomName").classList.contains("is-invalid")) {
            document.getElementById("roomName").classList.remove("is-invalid")
            document.getElementById("roomNameInvalidFeedback").innerHTML = "Bitte gib einen Raumnnamen an!"

        }
    });

    $("#roomName").on("keyup" ,function() {
        if(document.getElementById("roomName").classList.contains("is-invalid")) {
            document.getElementById("roomName").classList.remove("is-invalid")
            document.getElementById("roomNameInvalidFeedback").innerHTML = "Bitte gib einen Raumnnamen an!"
        }
    });

    const createRoomForm = document.getElementById("create-room-form");

    // To send a put request to the /api/room endpoint we need to listen if a submit event occurs and prevent the classic
    // html form submission as post request and perform our own checks and put request on it
    createRoomForm.addEventListener("submit", function (event) {
        // If create room form is valid, means if all input fields are valid
        if(createRoomForm.checkValidity()) {
            // Prevent classic html form submission as post request
            event.preventDefault()
            event.stopPropagation()

            // Disable all form input and select fields while creating room to prevent errors
            $('form input').prop('disabled', true);
            $('form select').prop('disabled', true);

            let divisionCount = 1;

            // If room mode is teamcanvas parse canvas division field as int and assign it to divisionCount
            if($('#roomMode').val() === "Team") {
                divisionCount = parseInt($('#canvasDivision').val())
            }

            // PUT request content to /api/room endpoint in json format
            let data = {
                "name": $('#roomName').val(),
                "width": parseInt($('#canvasWidth').val()),
                "height": parseInt($('#canvasHeight').val()),
                "divisionCount": divisionCount,
                "pixelSetDelay": parseInt($('#canvasPixelDelay').val())
            }

            // Send put request content to endpoint
            createRoom(data)
        } else {
            // Prevent form submission if some input field is invalid
            event.preventDefault()
            event.stopPropagation()
        }
        // For bootstrap form validation to work, we need to add was-validated to the class list of create room form
        createRoomForm.classList.add('was-validated')
    })
});

/**
 * Sends a http put request to the /api/room endpoint with json body and performs frontend changes depending on the api response
 *
 * @param data PUT request body in json
 * @returns void
 */
async function createRoom(data){
    let response = await fetch('/api/room', {method: 'PUT', headers: new Headers({'content-type': 'application/json'}) ,body: JSON.stringify(data)})

    if(response.status !== 200) {
        if(response.status === 409){ //Conflict, if roomname already exists

            // Changes the invalid feedback text
            document.getElementById("roomNameInvalidFeedback").innerHTML = "Leider ist dieser Raumnname schon vergeben, bitte wähle einen anderen"

            // Marks the roomname field
            document.getElementById("roomName").classList.add("is-invalid")

        }else{
            alert("Raum konnte nicht erstellt werden! Versuche es bitte nochmal!")
        }

        // If the room creation was not successful, let the user change his form input by re-enabling all input fields
        document.getElementById("create-room-form").classList.remove('was-validated')
        $('form input').prop('disabled', false);
        $('form select').prop('disabled', false);
    } else {
        let answer = await response.json();

        // Show room successfully created modal if api response status is 200
        $('#formSubmitModal').modal('show')

        // If room mode equals teamcanvas, get divsion access codes from api response and process them that the user knows
        // which access codes belongs to which divion
        if($('#roomMode').val() === "Team") {
            let divisionCodesText = '';

            for(let i = 0; i < answer["divisionCodes"].length; i++) {
                const divisionNumber = i + 1;
                divisionCodesText = divisionCodesText.concat("Abschnitt " + divisionNumber + ": " +  answer["divisionCodes"][i] + "\n")
            }

            // Fill frontend textarea with division codes
            $('#codesText').val(divisionCodesText)
        } else {
            // Fill frontend textarea with the room code if the room mode equals collabcanvas
            $('#codesText').val(answer["roomCode"])
        }

        // Fill frontend with the admin code
        $('#adminCodesText').val(answer["adminCode"])

        // For making the "Raum betreten" button within the modal work, we needed to fetch the room id from
        // the api /api/room endpoint by using findByName and set a hyper reference to the room url which needs this room id
        await setRoomIdForButtonHref($('#roomName').val())
    }
}

/** Sets the room id for the href when someone clicks on the join created room button
 *
 * @param name Name of the room
 */
async function setRoomIdForButtonHref(name){
    let response = await fetch('/api/room?findByName='+name);

    if (response.status !== 200){
        // If room id couldn't be found, hide the button
        $('#joinCreatedRoomButton').hide()
        return false;
    } else {
        let answer = await response.json();

        $('#joinCreatedRoomButton').on("click", function () {
            window.location.href = "canvas.html?roomID=" + answer["id"]
        })
    }
}