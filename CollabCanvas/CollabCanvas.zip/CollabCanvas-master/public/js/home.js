/*
 * @author Hartmann, Herbst
 */

/*
 * Add an entry to the html
 */
function createRoomEntry(name, roomId) {
    let entry = document.querySelector("#entry").content.cloneNode(true);

    entry.querySelector(".official-room-name").innerHTML = name;
    entry.querySelector(".official-room-join button").onclick = function () {
        window.location.href = `/canvas.html?roomID=${roomId}`;
    };
    document.querySelector("#official-rooms").appendChild(entry);
}

//gets the RoomId a given room name
async function getRoomId(name){
    let response = await fetch('/api/room?findByName='+name);

    if (response.status !== 200){
        return false;
    } else {
        let answer = await response.json();
        return answer["id"];
    }
}

/*
 * Get list of ofiicial rooms
 */
async function getOfficialRooms(){
    let response = await fetch('/api/room?isOfficial=true');
    if (response.status !== 200){
        return false;
    } else {
        let answer = await response.json();
        return answer;
    }
}

/*
 * Display rooms
 */
async function loadAndDisplayOfficalRooms(){
    let officialRooms = await getOfficialRooms();
    officialRooms.forEach(room =>{
        createRoomEntry(room.name, room.id);
    });
}

loadAndDisplayOfficalRooms();

/*
 * Join canvas and redirect
 */
async function joinButton(){
    let roomname = document.querySelector("#roomname").value;
    let result =  await getRoomId(roomname);
    if (result == false){
        if (document.querySelectorAll("#error-message").length < 1){

            let element = document.querySelector("#room-error-feedback").content.cloneNode(true);

            element.querySelector("#error-message").textContent = "Kein Raum unter diesem Namen gefunden!";
            document.querySelector("#join-room").append(element);
        }
    } else {
        window.location.href = `/canvas.html?roomID=${result}`;
    }
}
document.querySelector("#roomname").addEventListener('keydown',function (event){
    if(event.code === "Enter"){
        joinButton();
    }
});