/*
 * @author Hartmann, Herbst, Brieger
 */

// Classes for Canvas (img)
class Pixel{
    constructor(r, g, b){
        this.r = r;
        this.g = g;
        this.b = b;
    }
}
class Canvas{
    constructor(width, height){
        this.width = width;
        this.height = height;
        this.pixels = [];
    }

    generateExampleData(){
        for(let y = 0; y < height; y++){
            for(let x = 0; x < width; x++){
                this.pixels.push(new Pixel(Math.random()*255/*x*10%255*/, Math.random()*255/*y*5%255*/, Math.random()*255/*x%255*/));
            }
        }
    }
}

// Create Canvas
let canvas = document.getElementById('CollabCanvas');
let ctx = canvas.getContext('2d', {
    antialias: true,
    depth: false
});
let img = null/*new Canvas(1000, 1000)*/;

let imgData = null/*ctx.createImageData(img.width, img.height)*/;

function getDataPosForPixel(pixel){
    return (pixel.y * img.width + pixel.x) * 4;
}

let byteArray;
let currentImageUpdateId;

/**
 * fetches the full binary imagedata from the endpoint and writes it to a ImageData object directly
 * @returns void
 */
async function fetchFullImageData(){
    let arrayBuffer = await(await(await fetch("/api/room/"+roomId+"/canvas/imagedata")).blob()).arrayBuffer();
    console.log(arrayBuffer);
    byteArray = new Uint8Array(arrayBuffer);
    img = new Canvas(room.canvas.width, room.canvas.height);
    imgData = ctx.createImageData(img.width, img.height);
    //imgData.data = new Uint8ClampedArray(byteArray);

    for(let i = 0; i < img.width * img.height * 4; i+=4){
        imgData.data[i] = byteArray[i];
        imgData.data[i+1] = byteArray[i+1];
        imgData.data[i+2] = byteArray[i+2];
        imgData.data[i+3] = 255;
    }

    currentImageUpdateId =
        new DataView(arrayBuffer).getBigUint64(getDataPosForPixel({x: img.width, y: img.height-1}), true);
    console.log("fullImageData fetch lU: " + currentImageUpdateId);

    recreateImgBitmap();
    showDisplayName();
}

fetchFullImageData();

let displayNames = [];

async function fetchDisplayNames(){
    displayNames = await(await fetch("/api/room/"+roomId+"/canvas/displaynames")).json();
}

fetchDisplayNames()

/**
 * processes updates and writes them in-place to the ImageData Uint8ClampedArray
 */
async function processUpdates(){
    if(currentImageUpdateId === undefined){ //image not yet loaded
        return;
    }
    //console.log("Getting updates after " + currentImageUpdateId);
    let response = await fetch("/api/room/"+roomId+"/canvas/imageupdates?after="+currentImageUpdateId);
    if(response.status !== 200){
        console.log("Could not fetch imageupdates: " + response.status + " message: " + await response.json());
        fetchFullImageData();
        return;
    }

    let updateData = await response.json();
    for(const updateId in updateData.updates){
        let update = updateData.updates[updateId];
        let dataPos = getDataPosForPixel({x: update.x, y: update.y});
        imgData.data[dataPos++] = update.r;
        imgData.data[dataPos++] = update.g;
        imgData.data[dataPos++] = update.b;
        byteArray[dataPos] = update.lastEditedBy;
    }
    currentImageUpdateId = BigInt(updateData.updateId);
    console.log("New updateId: " + currentImageUpdateId);
    recreateImgBitmap();
    showDisplayName();
}

setInterval(processUpdates, 500);

let pixelLength = 1;
let displayPixelX = Math.ceil(window.innerWidth / pixelLength);
let displayPixelY = Math.ceil((window.innerHeight) / pixelLength);
let pos = null;

// moving
let lastUserPos = {x: 0, y: 0};
let startMoveUserPos = {x: 0, y: 0};
let posTmp = [0, 0];
let isClicked = false;

function move(userPos){
    // Move Canvas
    lastUserPos = userPos; //used for directional zooming
    if(isClicked){
        let xOffset = startMoveUserPos.x - userPos.x;
        let yOffset = startMoveUserPos.y - userPos.y;

        pos[0] = posTmp[0] - Math.round(xOffset);
        pos[1] = posTmp[1] - Math.round(yOffset);

        draw();
    }
}
/*
 * Update mouse position
 */
canvas.addEventListener("mousemove", function(event){
    move(getPosOnCanvas(event));
});

/*
 * Track path of mouse after click and hold for updating Canvas position
 */
function getPosOnCanvas(evt){
    let rect = canvas.getBoundingClientRect();
    return {
        x: Math.round(evt.clientX - rect.left),
        y: Math.round(evt.clientY - rect.top)
    };
}

function endMove(){
    isClicked = false;
    posTmp = [0, 0];
}

function startMove(userPos){
    isClicked = true;

    posTmp[0] = pos[0];
    posTmp[1] = pos[1];

    startMoveUserPos = userPos;
}

/*
 * Update selected Pixel and start tracking mouseposition on hold
 */
canvas.addEventListener('mousedown', function(event){
    startMove(getPosOnCanvas(event));

    selectedPixel = {
        x: Math.floor(startMoveUserPos.x / pixelLength - pos[0] / pixelLength),
        y: Math.floor(startMoveUserPos.y / pixelLength - pos[1] / pixelLength)
    };
    showDisplayName();

    draw();
});

canvas.addEventListener('mouseup', endMove);
canvas.addEventListener('mouseout', endMove);


/*
 * Zooming on Tablets and Smartphones
 */
let pinchStartDistance = 0;

function getPinchDistance(touches){
    let pos1 = getPosOnCanvas(touches[0]);
    let pos2 = getPosOnCanvas(touches[1]);
    return Math.sqrt((pos1.x - pos2.x) ** 2 + (pos1.y - pos2.y) ** 2);
}

function getCenterOfPinch(touches){
    let pos1 = getPosOnCanvas(touches[0]);
    let pos2 = getPosOnCanvas(touches[1]);
    return {x: (pos1.x + pos2.x) / 2, y: (pos1.y + pos2.y) / 2};
}

let pixelLengthPinchStart = pixelLength;

canvas.addEventListener('touchstart', function(event){
    if(event.touches.length === 1){
        //console.debug("startMove@1");
        startMove(getPosOnCanvas(event.touches[0]));
    }else if(event.touches.length === 2){
        pinchStartDistance = getPinchDistance(event.touches);
        //console.debug("startMove@2");
        pixelLengthPinchStart = pixelLength;
        startMove(getCenterOfPinch(event.touches));
    }
});

canvas.addEventListener('touchmove', function(event){
    if(event.touches.length === 1){
        move(getPosOnCanvas(event.touches[0]));
    }
    if(event.touches.length === 2){
        let pinchDiff = getPinchDistance(event.touches) - pinchStartDistance;
        move(getCenterOfPinch(event.touches));
        //console.log("pDiff"+pinchDiff);
        setZoom(pixelLengthPinchStart * (1 + (pinchDiff / 100)));
        startMove(getCenterOfPinch(event.touches));
    }
});

canvas.addEventListener('touchend', endMove);
canvas.addEventListener('touchcancel', endMove);

/*
 * Current selected pixel
 */
let selectedPixel = {x: 0, y: 0};

/*
 * Zooming with mouse wheel
 */
function setZoom(pL, button=false){
    // Calculate new position
    let xOffsetOld = (lastUserPos.x / pixelLength) - pos[0] / pixelLength;
    let yOffsetOld = (lastUserPos.y / pixelLength) - pos[1] / pixelLength;

    pixelLength = Math.max(Math.min(pL, 500), 0.1);

    if(!button){
        pos[0] = Math.round(((lastUserPos.x / pixelLength) - xOffsetOld) * pixelLength);
        pos[1] = Math.round(((lastUserPos.y / pixelLength) - yOffsetOld) * pixelLength);
    }
    draw();
}

/*
 * Buttons for zooming in/out and corresponding event-listeners
 */
let zoomInButton  = document.getElementById("zoomIn");
let zoomOutButton = document.getElementById("zoomOut");

zoomInButton.addEventListener('click', () => {
    setZoom(Math.max(pixelLength - pixelLength * (-200 / 400), 0.5), true);
});

zoomOutButton.addEventListener('click', () => {
    setZoom(Math.max(pixelLength - pixelLength * (200 / 400), 0.5), true);
});

function zoomChange(event){
    event.preventDefault();
    setZoom(Math.max(pixelLength - pixelLength * (event.deltaY / 400), 0.5));
}

window.addEventListener('resize', resizeCanvas, false);
canvas.addEventListener('wheel', zoomChange);

/*
 * Resizing the canvas
 */
function resizeCanvas(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    displayPixelX = Math.ceil(window.innerWidth / pixelLength);
    displayPixelY = Math.ceil((window.innerHeight) / pixelLength);
    draw();
}


/*
 * Draw canvas
 */
function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(
        imgBitmap, 0, 0, img.width, img.height, pos[0], pos[1],
        pixelLength * img.width, pixelLength * img.height
    );

    drawDivision();
    drawSelectedPixelBorder();
}

/*
 * Division handling
 */
let division = 0;
let showDivisionBox = document.getElementById("show-divisions");
function drawDivision() {
    if (divisionId == null) {
        showDivisionBox.style.display = "none";
    } else {
        showDivisionBox.style.display = "block";
    }

    if (divisionId !== null && showDivision) {
        let currentDivision = division[divisionId];
        let divisionWidth  = currentDivision.end.x - currentDivision.start.x + 1;
        let divisionHeight = currentDivision.end.y - currentDivision.start.y + 1;

        ctx.lineWidth = 2;
        ctx.strokeStyle = "#dbdbdb";
        ctx.setLineDash([10, 10]);
        ctx.strokeRect(pos[0] + currentDivision.start.x * pixelLength, pos[1] + currentDivision.start.y * pixelLength, divisionWidth * pixelLength, divisionHeight * pixelLength);
        ctx.setLineDash([]);
    }
}

/*
 * Draw Border around selected pixel
 */
function drawSelectedPixelBorder(){
    if(selectedPixel.x >= 0 && selectedPixel.y >= 0 && selectedPixel.x < img.width && selectedPixel.y < img.height){
        ctx.lineWidth = 5;
        ctx.strokeStyle = "#6c7a86"
        ctx.strokeRect(
            pos[0] + (selectedPixel.x) * pixelLength,
            pos[1] + (selectedPixel.y) * pixelLength, pixelLength, pixelLength);
    }
}

/*
 * Initial draw
 */
let imgBitmap = null;

function recreateImgBitmap(){
    createImageBitmap(imgData).then(function(newImgBitmap){
        imgBitmap = newImgBitmap;
        draw();
    });
    beforeFirstDrawInit();
}

let firstDraw = true;
function beforeFirstDrawInit(){
    if(!firstDraw){
        return;
    }
    firstDraw = false;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    // Center the canvas on screen
    pos = [displayPixelX / 2 - img.width / 2, displayPixelY / 2 - img.height / 2];

    if(roomId !== parseInt(localStorage["roomId"])){
        localStorage["lastEdited"] = 0;
        localStorage["roomId"] = roomId;
        console.log("new room");
    }
    let remaining = room.delay - Math.round((new Date().getTime() - parseInt(localStorage["lastEdited"]))/1000);
    if(remaining > 0){
        startTimer();
    }
}

function isOnCanvas(pixel){
    return (
        pixel.x >= 0 &&
        pixel.x < img.width &&
        pixel.y >= 0 &&
        pixel.y < img.height
    );
}

/**
 * author: Hartmann, Cislari
 * this function displays the name of the user who last edited the pixel.
 *
 * @returns void
 */
async function showDisplayName(){
    if(!isOnCanvas(selectedPixel)){
        document.getElementById('pixel-last-set-by').style.display = "none";
        return;
    }
    let displayNameId = byteArray[getDataPosForPixel(selectedPixel) + 3];

    if(displayNameId !== 0){
        if(displayNames[displayNameId-1] !== undefined){
            document.getElementById('pixel-last-set-by').innerText = displayNames[displayNameId-1];
        }else{ //fetch displayName manually, not (yet) present in cache
            let response = await fetch('/api/room/'+roomId+'/canvas/displayname/' + displayNameId);

            if(response.status !== 200){
                alert("displayname not found!");
            }else{
                document.getElementById('pixel-last-set-by').innerText = await response.json();
            }

            fetchDisplayNames() //refresh cache
        }
        document.getElementById('pixel-last-set-by').style.display = "initial";
    }else{
        document.getElementById('pixel-last-set-by').style.display = "none";
    }
}


let colors = document.querySelectorAll(".color-row div");
let currentColorId = 0;
let currentColor = [255, 255, 255];
/*
 * Get colors for pixels specified by css
 */
colors.forEach(colorbox => {
    colorbox.addEventListener('click', (event) => {
        colors[currentColorId].classList.toggle("color-selected");
        currentColorId = parseInt(event.target.id);
        colors[currentColorId].classList.toggle("color-selected");
        currentColor =
            window.getComputedStyle(event.target).backgroundColor.replace(/[^\d,]/g, '').split(',');
        console.log(currentColor);
        console.log(event.target);
    });
});

function changeColor(){
    // If the timer for the pixel delay has not finished then exit
    if(timerRunning){
        return;
    }

    // Start the timer
    localStorage["lastEdited"] = new Date().getTime();
	if (timerPrivilege != 1){ //dont start timer for admins and master
        startTimer();
    }

    // Update pixel
    let dataPixelPos = getDataPosForPixel(selectedPixel);

    imgData.data[dataPixelPos + 0] = currentColor[0];
    imgData.data[dataPixelPos + 1] = currentColor[1];
    imgData.data[dataPixelPos + 2] = currentColor[2];

    createImageBitmap(imgData).then(function(newImgBitmap){
        imgBitmap = newImgBitmap;
        draw();
    });

    sendColorChange();
}

/**
 * Sends a pixel change to the server
 *
 * @returns void
 */
async function sendColorChange(){
    let data = {
        x: selectedPixel.x, y: selectedPixel.y,
        r: parseInt(currentColor[0]), g: parseInt(currentColor[1]), b: parseInt(currentColor[2])
    };
    let response = await fetch('/api/room/'+roomId+'/canvas/pixel', {method: 'PUT', body: JSON.stringify(data)});

    if(response.status !== 200){
        switch(response.status){
            case 401:
                alert("Pixel kann nicht gesetzt werden: Nicht angemeldet!");
                break;
            case 403:
                alert("Pixel kann in diesem Bereich nicht gesetzt werden!");
                break;
            default:
                alert("Unbekannter Fehler beim Pixel setzen.");
                break;
        }
        stopTimer();

        fetchFullImageData();
    }
}


/*
 * Start timer
 */
let pixelSetButton = document.getElementById("set-pixel");
let timerRunning = false;
let timerInterval;
let timerPrivilege = 0;					   

function startTimer(){
    timerRunning = true;
    updateTimer();
    timerInterval = setInterval(updateTimer, 1000);
}

function stopTimer(){
    timerRunning = false;
    pixelSetButton.textContent = "Pixel setzen!";
    clearInterval(timerInterval);
}

function updateTimer(){
    // Stop the function if the countdown is finished
    let remainingSeconds = room.delay - Math.round((new Date().getTime() - parseInt(localStorage["lastEdited"]))/1000);
    if(remainingSeconds <= 0){
        stopTimer();
        return;
    }

    // Convert minutes to string with leading zeros
    let minutes = (Math.floor(remainingSeconds / 60)).toString().padStart(2, '0');

    // Convert seconds to string with leading zeros
    let seconds = (remainingSeconds % 60).toString().padStart(2, '0');

    // Update html
    pixelSetButton.textContent = `${minutes}:${seconds}`;
}

function setTimerPrivilege() {
    timerPrivilege = 1;
    stopTimer();
}

/*
 * Key handling
 */
let keyHandlingActivated = true;
document.addEventListener('keydown', function(event){
    // console.log(event.code);
    if (keyHandlingActivated){
        switch(event.code){
            case "KeyA":
                pos[0] -= 100;
                break;
            case "KeyD":
                pos[0] += 100;
                break;
            case "KeyW":
                pos[1] -= 100;
                break;
            case "KeyS":
                pos[1] += 100;
                break;
            case "ArrowLeft":
                selectedPixel.x--;
                break;
            case "ArrowRight":
                selectedPixel.x++;
                break;
            case "ArrowUp":
                selectedPixel.y--;
                break;
            case "ArrowDown":
                selectedPixel.y++;
                break;
            case "Enter":
            case "Space":
                changeColor();
                break;
            default:
                return;
        }
        draw();
        showDisplayName();
    }
});